<?php
declare(strict_types=1);

namespace App\Security;

final class SafeRedirect
{
    private const DEFAULT_TARGET = 'dashboard.php';

    private const ALLOWED_TARGETS = [
        'dashboard.php',
        'ordens-servico.php',
        'orcamentos.php',
        'clientes.php',
        'agenda.php',
        'painel-semanal.php',
        'pecas.php',
        'servicos.php',
        'tecnicos.php',
        'fornecedores.php',
        'transportadoras.php',
        'caixa.php',
        'faturamento.php',
        'relatorios.php',
        'configuracoes.php',
    ];

    public function sanitize(?string $next): string
    {
        $next = trim((string) $next);

        if ($next === '') {
            return self::DEFAULT_TARGET;
        }

        $decoded = rawurldecode($next);
        if (
            str_contains($decoded, "\0")
            || str_contains($decoded, '..')
            || str_starts_with($decoded, '/')
            || str_starts_with($decoded, '\\')
            || str_starts_with($decoded, '//')
            || preg_match('/^[a-z][a-z0-9+.-]*:/i', $decoded)
        ) {
            return self::DEFAULT_TARGET;
        }

        $target = strtok($decoded, '?') ?: $decoded;
        $fragmentlessTarget = strtok($target, '#') ?: $target;

        if (!in_array($fragmentlessTarget, self::ALLOWED_TARGETS, true)) {
            return self::DEFAULT_TARGET;
        }

        return $decoded;
    }
}
