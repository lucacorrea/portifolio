<?php

declare(strict_types=1);

require dirname(__DIR__) . '/src/Core/SqlStatementSplitter.php';
require dirname(__DIR__) . '/src/Core/MigrationException.php';
require dirname(__DIR__) . '/src/Core/MigrationRunner.php';

use App\Core\MigrationRunner;
use App\Core\SqlStatementSplitter;

function migrationAssertSame(mixed $expected, mixed $actual, string $message): void
{
    if ($expected !== $actual) {
        throw new RuntimeException($message . ' Esperado: ' . var_export($expected, true) . '; obtido: ' . var_export($actual, true));
    }
}

$sample = <<<'SQL'
-- comentário com ; não encerra comando
SET @sql := 'SELECT ''valor;interno''';
/* bloco ; ignorado */
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;
SQL;

$sampleStatements = SqlStatementSplitter::split($sample);
migrationAssertSame(4, count($sampleStatements), 'O parser deve respeitar comentários e ponto e vírgula dentro de string.');
migrationAssertSame(true, str_contains($sampleStatements[0], "valor;interno"), 'O conteúdo da string SQL deve ser preservado.');

$migrationPaths = glob(dirname(__DIR__) . '/database/migrations/*.sql') ?: [];
sort($migrationPaths, SORT_NATURAL | SORT_FLAG_CASE);
migrationAssertSame(29, count($migrationPaths), 'A sequência atual deve conter 29 migrations.');

$expectedVersion = 1;
foreach ($migrationPaths as $path) {
    $name = basename($path);
    migrationAssertSame(
        true,
        preg_match('/^(\d{3})_[a-z0-9_]+\.sql$/', $name, $matches) === 1,
        'Nome de migration inválido: ' . $name
    );
    migrationAssertSame($expectedVersion, (int) $matches[1], 'A sequência de migrations deve ser contínua.');
    migrationAssertSame(
        true,
        MigrationRunner::supportsVersion((int) $matches[1]),
        'Toda migration versionada deve estar homologada para execução automática.'
    );
    $sql = file_get_contents($path);
    migrationAssertSame(true, is_string($sql) && trim($sql) !== '', 'Migration vazia: ' . $name);
    migrationAssertSame(true, count(SqlStatementSplitter::split((string) $sql)) > 0, 'Migration sem comandos: ' . $name);
    ++$expectedVersion;
}

migrationAssertSame(false, MigrationRunner::supportsVersion($expectedVersion), 'Versão futura não pode ser executada sem homologação.');

$commissionMigration = file_get_contents(dirname(__DIR__) . '/database/migrations/014_create_monthly_commission_goals.sql');
migrationAssertSame(true, is_string($commissionMigration), 'A migration de metas mensais deve ser legível.');
migrationAssertSame(true, str_contains((string) $commissionMigration, 'uq_meta_comissao_competencia_ativa'), 'Apenas uma configuração ativa deve existir por competência.');
migrationAssertSame(true, str_contains((string) $commissionMigration, 'uq_meta_comissao_competencia_versao'), 'O histórico deve preservar versões da competência.');
migrationAssertSame(true, str_contains((string) $commissionMigration, 'relatorio.comissao.visualizar'), 'A permissão de visualização deve ser criada.');
migrationAssertSame(true, str_contains((string) $commissionMigration, 'relatorio.meta_comissao.configurar'), 'A permissão de configuração deve ser criada.');
migrationAssertSame(false, str_contains((string) $commissionMigration, 'DAYOFMONTH('), 'A migration deve evitar função incompatível com o analisador SQL da hospedagem.');
migrationAssertSame(false, str_contains((string) $commissionMigration, 'desativada_por IS NULL'), 'Coluna com ON DELETE SET NULL não pode participar de CHECK no MariaDB da hospedagem.');

$installmentMigration = file_get_contents(dirname(__DIR__) . '/database/migrations/015_accounts_payable_installments.sql');
migrationAssertSame(true, is_string($installmentMigration), 'A migration de parcelas deve ser legível.');
migrationAssertSame(true, str_contains((string) $installmentMigration, 'contas_pagar_parcelas'), 'A estrutura de parcelas deve ser criada.');
migrationAssertSame(true, str_contains((string) $installmentMigration, 'contas_pagar_parcela_eventos'), 'Quitações e estornos devem preservar histórico.');
migrationAssertSame(true, str_contains((string) $installmentMigration, 'contas_pagar.estornar_pagamento'), 'O estorno deve possuir permissão própria.');
migrationAssertSame(true, str_contains((string) $installmentMigration, 'caixa_movimentacao_id'), 'Quitações devem estar vinculadas às movimentações do Caixa.');

$cashMigration = file_get_contents(dirname(__DIR__) . '/database/migrations/016_cash_register_pos.sql');
migrationAssertSame(true, is_string($cashMigration), 'A migration do Caixa deve ser legível.');
migrationAssertSame(true, str_contains((string) $cashMigration, 'caixa_sessoes'), 'A sessão operacional de Caixa deve ser criada.');
migrationAssertSame(true, str_contains((string) $cashMigration, 'uq_caixa_sessao_aberta'), 'Somente uma sessão de Caixa pode permanecer aberta.');
migrationAssertSame(true, str_contains((string) $cashMigration, 'caixa_sessao_id'), 'Movimentações e vendas devem identificar sua sessão de Caixa.');
migrationAssertSame(true, str_contains((string) $cashMigration, 'saida_venda'), 'O estoque deve identificar baixas originadas pelo PDV.');
migrationAssertSame(true, str_contains((string) $cashMigration, 'caixa.registrar_venda'), 'A operação do PDV deve possuir permissão própria.');

$fiscalMigration = file_get_contents(dirname(__DIR__) . '/database/migrations/017_secure_fiscal_foundation.sql');
migrationAssertSame(true, is_string($fiscalMigration), 'A migration da fundação fiscal deve ser legível.');
migrationAssertSame(true, str_contains((string) $fiscalMigration, 'fiscal_certificados'), 'Certificados devem possuir armazenamento de metadados próprio.');
migrationAssertSame(true, str_contains((string) $fiscalMigration, 'senha_ciphertext'), 'Senha do certificado deve ser armazenada somente cifrada.');
migrationAssertSame(true, str_contains((string) $fiscalMigration, 'senha_tag'), 'Senha cifrada deve preservar a tag de autenticação AEAD.');
migrationAssertSame(true, str_contains((string) $fiscalMigration, 'csc_ciphertext'), 'CSC deve ser armazenado somente cifrado.');
migrationAssertSame(true, str_contains((string) $fiscalMigration, 'csc_tag'), 'CSC cifrado deve preservar a tag de autenticação AEAD.');
migrationAssertSame(true, str_contains((string) $fiscalMigration, 'uq_fiscal_configuracao_ativa'), 'Ambiente e modelo devem possuir apenas uma configuração ativa.');
migrationAssertSame(true, str_contains((string) $fiscalMigration, 'uq_fiscal_serie_ambiente_modelo'), 'Numeração deve ser isolada por ambiente, modelo e série.');
migrationAssertSame(true, str_contains((string) $fiscalMigration, 'fiscal_auditoria'), 'Operações fiscais sensíveis devem possuir auditoria própria.');
migrationAssertSame(false, str_contains((string) $fiscalMigration, 'certificado_senha VARCHAR'), 'Segredos fiscais não podem ser armazenados em texto puro.');
migrationAssertSame(false, str_contains((string) $fiscalMigration, ' csc VARCHAR'), 'CSC não pode ser armazenado em texto puro na fundação nova.');

$agendaReminderMigration = file_get_contents(dirname(__DIR__) . '/database/migrations/018_complete_agenda_reminders.sql');
migrationAssertSame(true, is_string($agendaReminderMigration), 'A migration de conclusão dos lembretes deve ser legível.');
migrationAssertSame(true, str_contains((string) $agendaReminderMigration, "ENUM('ativo', 'concluido', 'cancelado')"), 'Conclusão não pode reutilizar o estado cancelado.');
migrationAssertSame(true, str_contains((string) $agendaReminderMigration, 'concluido_em'), 'A conclusão deve registrar data e hora.');
migrationAssertSame(true, str_contains((string) $agendaReminderMigration, 'concluido_por'), 'A conclusão deve registrar o usuário responsável.');
migrationAssertSame(true, str_contains((string) $agendaReminderMigration, 'fk_agenda_lembretes_concluido_usuario'), 'A auditoria da conclusão deve preservar integridade referencial.');

$orderPaymentMigration = file_get_contents(dirname(__DIR__) . '/database/migrations/019_service_order_payment_receipts_permissions.sql');
migrationAssertSame(true, is_string($orderPaymentMigration), 'A migration do pagamento de OS deve ser legível.');
migrationAssertSame(true, str_contains((string) $orderPaymentMigration, 'payment_token'), 'Pagamento de OS deve possuir token idempotente persistente.');
migrationAssertSame(true, str_contains((string) $orderPaymentMigration, 'uq_os_pagamento_token'), 'Token de pagamento não pode ser reutilizado.');
migrationAssertSame(true, str_contains((string) $orderPaymentMigration, 'total_origem'), 'Estorno deve conseguir restaurar os totais anteriores da OS.');
migrationAssertSame(true, str_contains((string) $orderPaymentMigration, 'os.excluir'), 'A permissão de exclusão lógica deve ser reparada na migration.');
migrationAssertSame(true, str_contains((string) $orderPaymentMigration, 'recibo.emitir'), 'Emissão de recibo deve possuir permissão ativa.');

$productDeletionMigration = file_get_contents(dirname(__DIR__) . '/database/migrations/020_product_soft_deletion.sql');
migrationAssertSame(true, is_string($productDeletionMigration), 'A migration de exclusão lógica de produtos deve ser legível.');
migrationAssertSame(true, str_contains((string) $productDeletionMigration, 'excluido_em'), 'Produto excluído deve registrar data e hora.');
migrationAssertSame(true, str_contains((string) $productDeletionMigration, 'excluido_por'), 'Produto excluído deve registrar o usuário responsável.');
migrationAssertSame(true, str_contains((string) $productDeletionMigration, 'motivo_exclusao'), 'Produto excluído deve registrar o motivo.');
migrationAssertSame(true, str_contains((string) $productDeletionMigration, 'idx_produtos_exclusao'), 'Consultas devem possuir índice para exclusão lógica.');
migrationAssertSame(true, str_contains((string) $productDeletionMigration, 'fk_produtos_exclusao_usuario'), 'Auditoria da exclusão deve preservar integridade referencial.');
migrationAssertSame(true, str_contains((string) $productDeletionMigration, 'produto.excluir'), 'A permissão de excluir produtos deve ser reparada.');

$serviceOrderInstallmentsMigration = file_get_contents(dirname(__DIR__) . '/database/migrations/021_service_order_payment_installments.sql');
migrationAssertSame(true, is_string($serviceOrderInstallmentsMigration), 'A migration de parcelas do pagamento de OS deve ser legível.');
migrationAssertSame(true, str_contains((string) $serviceOrderInstallmentsMigration, 'quantidade_parcelas'), 'Pagamento e recibo devem persistir as parcelas.');
migrationAssertSame(true, str_contains((string) $serviceOrderInstallmentsMigration, "'boleto'"), 'Pagamento de OS deve reconhecer boleto compensado.');
migrationAssertSame(true, str_contains((string) $serviceOrderInstallmentsMigration, 'ALTER TABLE recibos'), 'Recibo deve manter snapshot da quantidade de parcelas.');

$masterDataDeletionMigration = file_get_contents(dirname(__DIR__) . '/database/migrations/022_master_data_soft_deletion.sql');
migrationAssertSame(true, is_string($masterDataDeletionMigration), 'A migration de exclusão lógica dos cadastros deve ser legível.');
foreach (['clientes', 'orcamentos', 'servicos'] as $table) {
    migrationAssertSame(true, str_contains((string) $masterDataDeletionMigration, 'ALTER TABLE ' . $table), 'A migration deve preparar exclusão lógica em ' . $table . '.');
}
foreach (['cliente.excluir', 'orcamento.excluir', 'servico.excluir'] as $permission) {
    migrationAssertSame(true, str_contains((string) $masterDataDeletionMigration, $permission), 'A migration deve reparar a permissão ' . $permission . '.');
}

$receiptPermissionMigration = file_get_contents(dirname(__DIR__) . '/database/migrations/023_repair_receipt_permissions.sql');
migrationAssertSame(true, is_string($receiptPermissionMigration), 'A migration de reparo das permissões de recibo deve ser legível.');
foreach (['recibo.visualizar', 'recibo.emitir', 'recibo.reimprimir', 'recibo.cancelar'] as $permission) {
    migrationAssertSame(true, str_contains((string) $receiptPermissionMigration, $permission), 'A migration deve reparar a permissão ' . $permission . '.');
}

$receiptRepairMigration = file_get_contents(dirname(__DIR__) . '/database/migrations/026_repair_receipt_schema.sql');
$migrationRunnerSource = file_get_contents(dirname(__DIR__) . '/src/Core/MigrationRunner.php');
migrationAssertSame(true, is_string($receiptRepairMigration), 'A migration de reparo do schema de recibos deve ser legível.');
migrationAssertSame(true, str_contains((string) $receiptRepairMigration, 'MODIFY COLUMN quantidade_parcelas SMALLINT UNSIGNED NOT NULL DEFAULT 1'), 'A migration deve normalizar tipo, nulabilidade e default das parcelas.');
foreach (['empresa_documento', 'empresa_telefone', 'empresa_endereco', 'quantidade_parcelas'] as $column) {
    migrationAssertSame(true, str_contains((string) $receiptRepairMigration, $column), 'A migration deve reparar a coluna de recibo ' . $column . '.');
    migrationAssertSame(true, str_contains((string) $migrationRunnerSource, "'" . $column . "'"), 'A pós-condição deve verificar a coluna de recibo ' . $column . '.');
}
$fiscalAuthorizationMigration = file_get_contents(dirname(__DIR__) . '/database/migrations/027_fiscal_authorization_hardening.sql');
migrationAssertSame(true, is_string($fiscalAuthorizationMigration), 'A migration de autorização fiscal deve ser legível.');
foreach (['uq_documento_fiscal_origem_normal', 'uq_documento_fiscal_chave', 'reconsulta_apos'] as $requirement) {
    migrationAssertSame(true, str_contains((string) $fiscalAuthorizationMigration, $requirement), 'A migration fiscal deve conter ' . $requirement . '.');
}

$serviceItemLocationMigration = file_get_contents(dirname(__DIR__) . '/database/migrations/029_service_order_item_execution_location.sql');
migrationAssertSame(true, is_string($serviceItemLocationMigration), 'A migration de local por serviço deve ser legível.');
migrationAssertSame(true, str_contains((string) $serviceItemLocationMigration, 'local_execucao'), 'O item da OS deve possuir local de execução próprio.');
echo "MigrationRunnerTest: OK\n";
