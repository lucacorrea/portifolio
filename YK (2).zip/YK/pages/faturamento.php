<?php

declare(strict_types=1);

require_once __DIR__ . '/../includes/ui.php';

$canViewFiscal = $authorization->can('nota_fiscal.visualizar');
$canIssueFiscal = $authorization->can('nota_fiscal.emitir');
$canCancelFiscal = $authorization->can('nota_fiscal.cancelar');
$canViewNfse = $authorization->can('nfse.visualizar');
$canIssueNfse = $authorization->can('nfse.emitir');
$canRequeryNfse = $authorization->can('nfse.reconsultar');
$canViewReceipts = $authorization->can('recibo.visualizar');
$canIssueReceipt = $authorization->can('recibo.emitir');
$canReprintReceipt = $authorization->can('recibo.reimprimir');
$runtime = $application->fiscalRuntimeReadiness()->inspect();
$overviewEnvironment = in_array((string) ($_GET['fiscal_environment'] ?? ''), ['homologacao', 'producao'], true)
  ? (string) $_GET['fiscal_environment']
  : 'homologacao';
$overviewModel = in_array((string) ($_GET['fiscal_model'] ?? ''), ['55', '65'], true)
  ? (string) $_GET['fiscal_model']
  : '65';
$fiscalOverview = null;
if ($canViewFiscal) {
    try {
        $fiscalOverview = $application->fiscalConfiguration()->overview($overviewEnvironment, $overviewModel);
    } catch (Throwable $exception) {
        error_log('Fiscal billing overview unavailable [' . get_class($exception) . '].');
    }
}
$readiness = is_array($fiscalOverview['readiness'] ?? null) ? $fiscalOverview['readiness'] : null;
$configuration = is_array($fiscalOverview['configuration'] ?? null) ? $fiscalOverview['configuration'] : null;
$fiscalFilters = [
  'search' => trim((string) ($_GET['fiscal_search'] ?? '')),
  'status' => trim((string) ($_GET['fiscal_status'] ?? '')),
  'modelo' => trim((string) ($_GET['fiscal_model'] ?? '')),
  'ambiente' => trim((string) ($_GET['fiscal_environment'] ?? '')),
];
$fiscalDocuments = [];
if ($canViewFiscal) {
  try {
    $fiscalDocuments = $application->fiscalDocuments()->listDocuments($fiscalFilters);
  } catch (Throwable $exception) {
    error_log('Fiscal document listing unavailable [' . get_class($exception) . '].');
  }
}
$nfseDocuments = [];
if ($canViewNfse) {
  try { $nfseDocuments = $application->nfseDocuments()->list(); }
  catch (Throwable $exception) { error_log('NFS-e listing unavailable [' . get_class($exception) . '].'); }
}
$receiptFilters = [
  'search' => trim((string) ($_GET['search'] ?? '')),
  'status' => trim((string) ($_GET['receipt_status'] ?? '')),
  'type' => trim((string) ($_GET['receipt_type'] ?? '')),
];
if (!in_array($receiptFilters['status'], ['', 'emitido', 'cancelado'], true)) $receiptFilters['status'] = '';
if (!in_array($receiptFilters['type'], ['', 'os', 'avulso'], true)) $receiptFilters['type'] = '';
$receipts = [];
if ($canViewReceipts && method_exists($application->receiptService(), 'listReceipts')) {
  try {
    $receipts = $application->receiptService()->listReceipts($receiptFilters);
  } catch (Throwable $exception) {
    error_log('Receipt listing unavailable [' . get_class($exception) . '].');
  }
}
$receiptClients = $canIssueReceipt ? array_values(array_filter(
  $application->clientManagement()->listClients(),
  static fn($client): bool => $client->status() === 'ativo'
)) : [];

function billing_receipt_money(mixed $value): string { return money((string) $value); }
function billing_receipt_date(mixed $value): string
{
  try { return (new DateTimeImmutable((string) $value))->format('d/m/Y H:i'); }
  catch (Throwable) { return '-'; }
}
function billing_receipt_type(array $receipt): string
{
  return !empty($receipt['pagamento_id']) || !empty($receipt['ordem_servico_id']) ? 'OS' : 'Avulso';
}
?>

<div class="page-body">
  <?php if ($canViewFiscal): ?>
    <section class="panel mb-4">
      <div class="panel-header"><div class="panel-title"><i class="bi bi-receipt-cutoff"></i>Emissão fiscal</div><?php if ($authorization->can('nota_fiscal.configurar')): ?><a class="btn-filter btn-filter-primary" href="configuracoes-fiscais.php"><i class="bi bi-gear"></i> Configurar</a><?php endif; ?></div>
      <div class="p-3">
        <div class="row g-3">
          <div class="col-12 col-md-4"><div class="border rounded-3 p-3 h-100"><span class="text-muted d-block">Ambiente</span><strong><?= h(ucfirst($overviewEnvironment)) ?></strong></div></div>
          <div class="col-12 col-md-4"><div class="border rounded-3 p-3 h-100"><span class="text-muted d-block">Configuração <?= $overviewModel === '55' ? 'NF-e' : 'NFC-e' ?></span><strong><?= $configuration === null ? 'Não configurada' : h((string) $configuration['status']) ?></strong></div></div>
          <div class="col-12 col-md-4"><div class="border rounded-3 p-3 h-100"><span class="text-muted d-block">Comunicação SEFAZ</span><strong><?= ($overviewEnvironment === 'producao' ? $runtime['production_allowed'] : $runtime['homologation_ready']) && $readiness !== null && $readiness['ready'] ? 'Pronta para teste técnico' : 'Bloqueada por pendências' ?></strong></div></div>
        </div>
        <?php if ($readiness !== null && $readiness['errors'] !== []): ?><div class="alert alert-warning mt-3 mb-0">Existem <?= count($readiness['errors']) ?> pendência(s) cadastral(is) ou técnica(s). Consulte a Configuração Fiscal.</div><?php endif; ?>
        <?php if ($fiscalOverview === null): ?><div class="alert alert-warning mt-3 mb-0">A fundação fiscal ainda não está disponível no banco.</div><?php endif; ?>
      </div>
    </section>

    <section class="panel mb-4" id="documentos-fiscais">
      <div class="panel-header"><div><div class="panel-title"><i class="bi bi-file-earmark-code"></i>Documentos NF-e / NFC-e</div><p class="text-muted small mb-0 mt-1">A tela não simula notas fiscais. DANFE e DANFCE só são liberados a partir do XML autorizado pela SEFAZ. Serviços permanecem separados e exigem NFS-e.</p></div></div>
      <form class="filter-bar" method="get" action="faturamento.php" data-live-filter="fiscal-documents" data-live-regions="fiscal-results">
        <div class="search-wrap"><i class="bi bi-search"></i><input class="search-input" name="fiscal_search" value="<?= h($fiscalFilters['search']) ?>" placeholder="Chave, cliente ou OS"></div>
        <select class="filter-select" name="fiscal_model" aria-label="Modelo fiscal"><option value="">NF-e e NFC-e</option><option value="55" <?= $fiscalFilters['modelo'] === '55' ? 'selected' : '' ?>>NF-e (55)</option><option value="65" <?= $fiscalFilters['modelo'] === '65' ? 'selected' : '' ?>>NFC-e (65)</option></select>
        <select class="filter-select" name="fiscal_environment" aria-label="Ambiente fiscal"><option value="">Todos os ambientes</option><option value="homologacao" <?= $fiscalFilters['ambiente'] === 'homologacao' ? 'selected' : '' ?>>Homologação</option><option value="producao" <?= $fiscalFilters['ambiente'] === 'producao' ? 'selected' : '' ?>>Produção</option></select>
        <select class="filter-select" name="fiscal_status" aria-label="Status fiscal"><option value="">Todos os status</option><?php foreach (['preparado','processando','pendente_reconsulta','autorizado','rejeitado','denegado','cancelado','erro_tecnico'] as $status): ?><option value="<?= h($status) ?>" <?= $fiscalFilters['status'] === $status ? 'selected' : '' ?>><?= h(ucfirst(str_replace('_', ' ', $status))) ?></option><?php endforeach; ?></select>
        <button class="btn-filter btn-filter-primary" type="submit"><i class="bi bi-funnel"></i> Filtrar</button>
        <a class="btn-filter btn-filter-ghost" href="faturamento.php#documentos-fiscais" data-live-filter-clear><i class="bi bi-x-lg"></i> Limpar</a>
      </form>
      <div data-live-region="fiscal-results">
        <?php if ($fiscalDocuments === []): ?>
          <div class="empty-state py-5"><i class="bi bi-shield-exclamation"></i><h3>Nenhum documento fiscal</h3><p>Use uma OS finalizada ou uma conta paga para emitir NF-e/NFC-e das peças. Serviços ficam vinculados à mesma OS para a NFS-e separada.</p></div>
        <?php else: ?>
          <div class="table-panel-wrap"><table class="os-table"><thead><tr><th>Documento</th><th>Origem</th><th>Cliente</th><th>Valor</th><th>Status</th><th>Chave / motivo</th><th>Ações</th></tr></thead><tbody>
          <?php foreach ($fiscalDocuments as $document): ?>
            <tr>
              <td><strong><?= ($document['modelo'] ?? '') === '55' ? 'NF-e' : 'NFC-e' ?> <?= h((string) ($document['serie'] ?? '')) ?>/<?= h((string) ($document['numero'] ?? '')) ?></strong><br><small class="text-muted"><?= h((string) ($document['ambiente'] ?? '')) ?></small></td>
              <td><?= h((string) ($document['os_numero'] ?? '-')) ?></td>
              <td><?= h((string) ($document['cliente_nome'] ?? '-')) ?></td>
              <td><strong><?= h(billing_receipt_money($document['valor_nota'] ?? '0')) ?></strong></td>
              <td><span class="badge-soft badge-<?= ($document['processamento_status'] ?? '') === 'autorizado' ? 'green' : (($document['processamento_status'] ?? '') === 'rejeitado' ? 'red' : 'amber') ?>"><?= h(ucfirst(str_replace('_', ' ', (string) ($document['processamento_status'] ?? 'rascunho')))) ?></span></td>
              <td><?php if (!empty($document['chave'])): ?><small><?= h((string) $document['chave']) ?></small><?php else: ?><?= h((string) ($document['xmotivo'] ?? 'Aguardando transmissão/autorização')) ?><?php endif; ?></td>
              <td class="table-actions-cell">
                <?php $documentStatus = (string) ($document['processamento_status'] ?? ''); ?>
                <?php if ($documentStatus === 'autorizado' || ($canIssueFiscal && in_array($documentStatus, ['preparado', 'processando', 'pendente_reconsulta', 'rejeitado'], true))): ?>
                  <div class="dropdown table-action-dropdown"><button class="btn-action" type="button" data-bs-toggle="dropdown" aria-expanded="false" aria-label="Ações do documento fiscal"><i class="bi bi-three-dots-vertical"></i></button><ul class="dropdown-menu dropdown-menu-end">
                    <?php if ($documentStatus === 'autorizado'): ?><li><a class="dropdown-item" href="nota-fiscal-imprimir.php?id=<?= h((string) $document['id']) ?>" target="_blank" rel="noopener"><i class="bi bi-printer"></i> Imprimir <?= ($document['modelo'] ?? '') === '55' ? 'DANFE' : 'DANFCE' ?></a></li><?php if ($authorization->can('nota_fiscal.baixar_xml')): ?><li><a class="dropdown-item" href="nota-fiscal-xml.php?id=<?= h((string) $document['id']) ?>"><i class="bi bi-filetype-xml"></i> Baixar XML autorizado</a></li><?php endif; ?><?php if ($canCancelFiscal): ?><li><hr class="dropdown-divider"></li><li><button class="dropdown-item text-danger js-fiscal-cancel" type="button" data-document-id="<?= h((string) $document['id']) ?>" data-bs-toggle="modal" data-bs-target="#modal-fiscal-cancel"><i class="bi bi-x-octagon"></i> Cancelar na SEFAZ</button></li><?php endif; ?>
                    <?php elseif ($documentStatus === 'preparado'): ?><li><form method="post" action="actions/nota-fiscal-transmitir.php"><?= $csrf->field() ?><?php return_to_field(); ?><input type="hidden" name="documento_fiscal_id" value="<?= h((string) $document['id']) ?>"><button class="dropdown-item" type="submit"><i class="bi bi-cloud-arrow-up"></i> Transmitir à SEFAZ</button></form></li>
                    <?php elseif (in_array($documentStatus, ['processando', 'pendente_reconsulta'], true)): ?><li><form method="post" action="actions/nota-fiscal-reconsultar.php"><?= $csrf->field() ?><?php return_to_field(); ?><input type="hidden" name="documento_fiscal_id" value="<?= h((string) $document['id']) ?>"><button class="dropdown-item" type="submit"><i class="bi bi-arrow-repeat"></i> Reconsultar na SEFAZ</button></form></li>
                    <?php else: ?><li><form method="post" action="actions/nota-fiscal-preparar.php"><?= $csrf->field() ?><?php return_to_field(); ?><input type="hidden" name="ordem_servico_id" value="<?= h((string) $document['ordem_servico_id']) ?>"><input type="hidden" name="modelo" value="<?= h((string) $document['modelo']) ?>"><input type="hidden" name="ambiente" value="<?= h((string) $document['ambiente']) ?>"><input type="hidden" name="idempotency_key" value="<?= h(bin2hex(random_bytes(32))) ?>"><button class="dropdown-item" type="submit"><i class="bi bi-arrow-clockwise"></i> Repreparar após corrigir cadastro</button></form></li><?php endif; ?>
                  </ul></div>
                <?php else: ?>—<?php endif; ?>
              </td>
            </tr>
          <?php endforeach; ?>
          </tbody></table></div>
        <?php endif; ?>
      </div>
    </section>
  <?php endif; ?>

  <?php if ($canViewNfse): ?>
    <section class="panel mb-4" id="documentos-nfse">
      <div class="panel-header"><div><div class="panel-title"><i class="bi bi-building-check"></i>Serviços — DPS / NFS-e</div><p class="text-muted small mb-0 mt-1">Fluxo municipal Betha separado dos documentos estaduais. Uma DPS é criada por perfil fiscal compatível.</p></div></div>
      <?php if ($nfseDocuments === []): ?>
        <div class="empty-state py-5"><i class="bi bi-file-earmark-text"></i><h3>Nenhuma DPS preparada</h3><p>Conclua os dados fiscais do serviço e prepare a NFS-e a partir de uma OS finalizada.</p></div>
      <?php else: ?>
        <div class="table-panel-wrap"><table class="os-table"><thead><tr><th>DPS / NFS-e</th><th>OS</th><th>Cliente</th><th>Serviços</th><th>Status</th><th>Protocolo / motivo</th><th>Ações</th></tr></thead><tbody>
        <?php foreach ($nfseDocuments as $document): $status=(string)$document['status']; ?>
          <tr>
            <td><strong>DPS <?= h((string)$document['serie_dps']) ?>/<?= h((string)$document['numero_dps']) ?></strong><?php if (!empty($document['numero_nfse'])): ?><br><small>NFS-e <?= h((string)$document['numero_nfse']) ?></small><?php endif; ?></td>
            <td><?= h((string)$document['os_numero']) ?></td><td><?= h((string)$document['cliente_nome']) ?></td>
            <td><strong><?= h(billing_receipt_money($document['valor_servicos'])) ?></strong></td>
            <td><span class="badge-soft badge-<?= $status==='autorizado'?'green':(str_starts_with($status,'rejeitado')?'red':'amber') ?>"><?= h(ucfirst(str_replace('_',' ',$status))) ?></span></td>
            <td><?= h((string)($document['protocolo'] ?: $document['mensagem'] ?: 'Aguardando ação')) ?></td>
            <td class="table-actions-cell"><div class="dropdown table-action-dropdown"><button class="btn-action" type="button" data-bs-toggle="dropdown" aria-expanded="false" aria-label="Ações da NFS-e"><i class="bi bi-three-dots-vertical"></i></button><ul class="dropdown-menu dropdown-menu-end">
              <?php if ($status==='preparado' && $canIssueNfse): ?><li><form method="post" action="actions/nfse-transmitir.php"><?= $csrf->field() ?><?php return_to_field(); ?><input type="hidden" name="nfse_documento_id" value="<?= h((string)$document['id']) ?>"><button class="dropdown-item" type="submit"><i class="bi bi-cloud-arrow-up"></i> Transmitir DPS</button></form></li><?php endif; ?>
              <?php if ($status==='aguardando_validacao' && $canRequeryNfse): ?><li><form method="post" action="actions/nfse-reconsultar.php"><?= $csrf->field() ?><?php return_to_field(); ?><input type="hidden" name="nfse_documento_id" value="<?= h((string)$document['id']) ?>"><button class="dropdown-item" type="submit"><i class="bi bi-arrow-repeat"></i> Consultar protocolo</button></form></li><?php endif; ?>
              <?php if ($status==='autorizado' && !empty($document['pdf_url'])): ?><li><a class="dropdown-item" href="<?= h((string)$document['pdf_url']) ?>" target="_blank" rel="noopener noreferrer"><i class="bi bi-printer"></i> Abrir DANFSe</a></li><?php endif; ?>
              <?php if (!in_array($status,['preparado','aguardando_validacao','autorizado'],true)): ?><li><span class="dropdown-item-text text-muted">Sem ação disponível</span></li><?php endif; ?>
            </ul></div></td>
          </tr>
        <?php endforeach; ?>
        </tbody></table></div>
      <?php endif; ?>
    </section>
  <?php endif; ?>

  <?php if ($authorization->canAny(['recibo.visualizar', 'recibo.emitir', 'boleto.visualizar'])): ?>
    <section class="panel" id="recibos">
      <div class="panel-header"><div><div class="panel-title"><i class="bi bi-journal-check"></i>Recibos</div><p class="text-muted small mb-0 mt-1">Documentos não fiscais de pagamentos de OS ou recebimentos avulsos.</p></div><?php if ($canIssueReceipt): ?><button class="btn-filter btn-filter-primary" type="button" data-bs-toggle="modal" data-bs-target="#modal-standalone-receipt"><i class="bi bi-plus-lg"></i> Novo recibo</button><?php endif; ?></div>
      <?php if ($canViewReceipts): ?>
        <form class="filter-bar" method="get" action="faturamento.php" data-live-filter="receipts" data-live-regions="receipt-results">
          <div class="search-wrap"><i class="bi bi-search"></i><input class="search-input" type="search" name="search" value="<?= h($receiptFilters['search']) ?>" placeholder="Número, cliente ou descrição"></div>
          <select class="filter-select" name="receipt_type" aria-label="Tipo do recibo"><option value="">Todos os tipos</option><option value="os" <?= $receiptFilters['type'] === 'os' ? 'selected' : '' ?>>Pagamento de OS</option><option value="avulso" <?= $receiptFilters['type'] === 'avulso' ? 'selected' : '' ?>>Avulso</option></select>
          <select class="filter-select" name="receipt_status" aria-label="Status do recibo"><option value="">Todos os status</option><option value="emitido" <?= $receiptFilters['status'] === 'emitido' ? 'selected' : '' ?>>Emitidos</option><option value="cancelado" <?= $receiptFilters['status'] === 'cancelado' ? 'selected' : '' ?>>Cancelados</option></select>
          <button class="btn-filter btn-filter-primary" type="submit"><i class="bi bi-funnel"></i> Filtrar</button>
          <a class="btn-filter btn-filter-ghost" href="faturamento.php#recibos" data-live-filter-clear><i class="bi bi-x-lg"></i> Limpar</a>
        </form>
        <div data-live-region="receipt-results">
          <?php if ($receipts === []): ?>
            <?php empty_state('Nenhum recibo encontrado', 'Emita um recibo avulso ou registre o pagamento de uma OS.'); ?>
          <?php else: ?>
            <div class="table-panel-wrap"><table class="os-table"><thead><tr><th>Recibo</th><th>Tipo</th><th>Cliente</th><th>Descrição</th><th>Valor</th><th>Emissão</th><th>Status</th><th>Ações</th></tr></thead><tbody>
            <?php foreach ($receipts as $receipt): ?>
              <tr>
                <td><strong><?= h((string) ($receipt['numero'] ?? '')) ?></strong><?php if (!empty($receipt['os_numero'])): ?><br><small class="text-muted"><?= h((string) $receipt['os_numero']) ?></small><?php endif; ?></td>
                <td><?= h(billing_receipt_type($receipt)) ?></td>
                <td><?= h((string) ($receipt['cliente_nome'] ?? 'Cliente avulso')) ?></td>
                <td class="receipt-description-cell"><?= h((string) ($receipt['descricao'] ?? '')) ?></td>
                <td><strong><?= h(billing_receipt_money($receipt['valor'] ?? '0')) ?></strong></td>
                <td><?= h(billing_receipt_date($receipt['emitido_em'] ?? null)) ?></td>
                <td><span class="badge-soft badge-<?= ($receipt['status'] ?? '') === 'emitido' ? 'green' : 'gray' ?>"><?= ($receipt['status'] ?? '') === 'emitido' ? 'Emitido' : 'Cancelado' ?></span></td>
                <td class="table-actions-cell"><?php if ($canReprintReceipt): ?><div class="dropdown table-action-dropdown"><button class="btn-action" type="button" data-bs-toggle="dropdown" aria-expanded="false" aria-label="Ações do recibo <?= h((string) ($receipt['numero'] ?? '')) ?>"><i class="bi bi-three-dots-vertical"></i></button><ul class="dropdown-menu dropdown-menu-end"><li><a class="dropdown-item" href="recibo-imprimir.php?id=<?= h((string) $receipt['id']) ?>" target="_blank" rel="noopener"><i class="bi bi-printer"></i> Imprimir recibo</a></li></ul></div><?php else: ?>—<?php endif; ?></td>
              </tr>
            <?php endforeach; ?>
            </tbody></table></div>
          <?php endif; ?>
        </div>
      <?php else: ?>
        <div class="p-3"><div class="alert alert-info mb-0">Você pode emitir recibos, mas não possui permissão para consultar o histórico.</div></div>
      <?php endif; ?>
    </section>
  <?php endif; ?>
</div>

<?php if ($canIssueReceipt): ?>
<div class="modal fade" id="modal-standalone-receipt" tabindex="-1" aria-hidden="true"><div class="modal-dialog modal-lg modal-dialog-scrollable"><form class="modal-content visual-modal" method="post" action="actions/recibo-avulso-emitir.php" target="_blank" autocomplete="off"><div class="modal-header"><div><h2 class="modal-title fs-5">Novo recibo</h2><p class="text-muted small mb-0">Use um cliente cadastrado ou informe os dados de um recebimento avulso.</p></div><button class="btn-close" type="button" data-bs-dismiss="modal" aria-label="Fechar"></button></div><div class="modal-body"><?= $csrf->field() ?><?php return_to_field(); ?><div class="alert alert-info"><i class="bi bi-image"></i> A logo e os dados atuais da empresa serão incluídos automaticamente no recibo.</div><fieldset class="form-section"><legend class="form-section-title">Cliente</legend><div class="form-row"><div class="form-group"><label class="form-label" for="standalone-receipt-mode">Origem do cliente</label><select class="form-control-os" id="standalone-receipt-mode"><option value="registered" <?= $receiptClients !== [] ? 'selected' : '' ?>>Cliente cadastrado</option><option value="standalone" <?= $receiptClients === [] ? 'selected' : '' ?>>Cliente avulso</option></select></div><div class="form-group" data-receipt-registered-client><label class="form-label" for="standalone-receipt-client">Cliente cadastrado</label><select class="form-control-os" id="standalone-receipt-client" name="cliente_id"><option value="">Selecione</option><?php foreach ($receiptClients as $client): ?><option value="<?= h((string) $client->id()) ?>"><?= h($client->name()) ?></option><?php endforeach; ?></select></div></div><div class="form-row" data-receipt-standalone-client><div class="form-group"><label class="form-label" for="standalone-receipt-name">Nome do cliente</label><input class="form-control-os" id="standalone-receipt-name" name="cliente_nome" maxlength="150"></div><div class="form-group"><label class="form-label" for="standalone-receipt-document">CPF/CNPJ <span class="text-muted">(opcional)</span></label><input class="form-control-os" id="standalone-receipt-document" name="cliente_documento" maxlength="20"></div></div></fieldset><fieldset class="form-section"><legend class="form-section-title">Recebimento</legend><div class="form-group"><label class="form-label" for="standalone-receipt-description">Referente a</label><textarea class="form-control-os" id="standalone-receipt-description" name="descricao" maxlength="1000" rows="4" required></textarea></div><div class="form-row"><div class="form-group"><label class="form-label" for="standalone-receipt-value">Valor</label><input class="form-control-os" id="standalone-receipt-value" name="valor" inputmode="decimal" required></div><div class="form-group"><label class="form-label" for="standalone-receipt-payment">Forma de pagamento</label><select class="form-control-os" id="standalone-receipt-payment" name="forma_pagamento" required><option value="dinheiro">Dinheiro</option><option value="pix">Pix</option><option value="cartao_debito">Cartão de débito</option><option value="cartao_credito">Cartão de crédito</option><option value="transferencia">Transferência</option><option value="outro">Outro</option></select></div></div></fieldset></div><div class="modal-footer"><button class="btn-modal-cancel" type="button" data-bs-dismiss="modal">Cancelar</button><button class="btn-modal-save" type="submit"><i class="bi bi-receipt-cutoff"></i> Emitir e abrir recibo</button></div></form></div></div></div>
<?php endif; ?>

<?php if ($canCancelFiscal): ?>
<div class="modal fade" id="modal-fiscal-cancel" tabindex="-1" aria-hidden="true"><div class="modal-dialog modal-dialog-centered"><form class="modal-content visual-modal" method="post" action="actions/nota-fiscal-cancelar.php"><div class="modal-header"><div><h2 class="modal-title fs-5">Cancelar documento fiscal</h2><p class="text-muted small mb-0">A solicitação será enviada à SEFAZ e ficará auditada.</p></div><button class="btn-close" type="button" data-bs-dismiss="modal" aria-label="Fechar"></button></div><div class="modal-body"><?= $csrf->field() ?><?php return_to_field(); ?><input type="hidden" name="documento_fiscal_id" id="fiscal-cancel-document-id"><div class="alert alert-warning">Depois da autorização do cancelamento, a OS poderá ser estornada. Pagamentos e estoque continuam sendo corrigidos por lançamentos de estorno.</div><div class="form-group"><label class="form-label" for="fiscal-cancel-reason">Justificativa</label><textarea class="form-control-os" id="fiscal-cancel-reason" name="justificativa" minlength="15" maxlength="255" rows="4" required></textarea></div></div><div class="modal-footer"><button class="btn-modal-cancel" type="button" data-bs-dismiss="modal">Voltar</button><button class="btn-modal-save" type="submit"><i class="bi bi-x-octagon"></i> Solicitar cancelamento</button></div></form></div></div>
<script>document.addEventListener('click',function(event){const button=event.target.closest('.js-fiscal-cancel');if(!button)return;const input=document.getElementById('fiscal-cancel-document-id');if(input)input.value=button.dataset.documentId||'';});</script>
<?php endif; ?>
