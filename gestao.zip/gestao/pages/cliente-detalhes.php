<?php

declare(strict_types=1);

require_once __DIR__ . '/../backend/bootstrap.php';

use App\Security\Auth;

Auth::requireLogin();

$user = Auth::user();


$pageId = 'cliente-detalhes';
$pageTitle = 'Cliente';
$activeMenu = 'clientes';
require_once __DIR__ . '/layout/header.php';
?>
      
<header class="plain-header">
  
   
    
  <div class="page-title-row">
    <a class="back-btn" href="clientes.php">‹</a>
    <div>
      <p class="micro-label dark-text">Conta do cliente</p>
      <h1 id="clientNameTitle">Cliente</h1>
    </div>
    <span></span>
  </div>
</header>

<section class="content-pad" id="clientDetailContent"></section>

<?php require_once __DIR__ . '/layout/footer.php'; ?>
