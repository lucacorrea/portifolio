# Gestão Comercial Premium - Demo HTML/CSS/JS

Projeto front-end demonstrativo para apresentar um sistema comercial/frente de caixa com visual mobile premium.

## Tecnologias

- HTML5
- CSS3
- JavaScript
- Chart.js via CDN
- Layout mobile-first
- Material/Fintech inspired UI

## Como rodar

Abra o arquivo `index.html` no navegador.

Para testar como app no celular:

1. Suba a pasta para a Hostinger ou qualquer hospedagem.
2. Acesse o link pelo celular.
3. No Chrome Android, toque em `⋮ > Adicionar à tela inicial`.

## Estrutura

```txt
index.html
assets/
  css/
    styles.css
  js/
    app.js
```

## Próximo passo recomendado

Transformar esta demo em PWA com `manifest.json` e `service-worker.js`, depois integrar com API PHP/MySQL.
