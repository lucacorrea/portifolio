const money = new Intl.NumberFormat('pt-BR', {
  style: 'currency',
  currency: 'BRL'
});

const state = {
  finance: [
    {
      label: 'Total vendido',
      value: 8742.90,
      note: '+18,4% hoje',
      accent: '#1768D5',
      bg: 'rgba(23,104,213,.12)'
    },
    {
      label: 'PIX',
      value: 3820.40,
      note: '44% das vendas',
      accent: '#12BFA2',
      bg: 'rgba(18,191,162,.13)'
    },
    {
      label: 'Cartão',
      value: 3654.10,
      note: 'Crédito e débito',
      accent: '#19B7D8',
      bg: 'rgba(25,183,216,.13)'
    },
    {
      label: 'Dinheiro',
      value: 1268.40,
      note: '14 pagamentos',
      accent: '#F7B731',
      bg: 'rgba(247,183,49,.14)'
    },
    {
      label: 'Lucro estimado',
      value: 2797.72,
      note: 'Margem 32%',
      accent: '#25C486',
      bg: 'rgba(37,196,134,.14)'
    }
  ],

  latestSales: [
    { customer: 'Cliente balcão', method: 'PIX', time: '09:42', amount: 246.80 },
    { customer: 'Mariana Costa', method: 'Cartão', time: '10:16', amount: 589.90 },
    { customer: 'Rafael Lima', method: 'Dinheiro', time: '10:37', amount: 79.90 },
    { customer: 'Mercado São João', method: 'PIX', time: '11:04', amount: 1390.00 }
  ],

  topProducts: [
    { name: 'Mouse Sem Fio Pro', qty: '28 un.', amount: 2237.20 },
    { name: 'Cabo USB-C 2m', qty: '41 un.', amount: 697.00 },
    { name: 'Teclado Mecânico', qty: '12 un.', amount: 1798.80 }
  ],

  lowStock: [
    { name: 'Fonte 12V 5A', qty: '3 un.', amount: 0 },
    { name: 'Adaptador HDMI', qty: '5 un.', amount: 0 },
    { name: 'Hub USB-C', qty: '2 un.', amount: 0 }
  ],

  catalog: [
    { name: 'Teclado Mecânico RGB', sku: 'SKU-1009', price: 149.90, stock: 18 },
    { name: 'Mouse Sem Fio Pro', sku: 'SKU-1011', price: 79.90, stock: 42 },
    { name: 'Cabo USB-C 2m', sku: 'SKU-1018', price: 17.00, stock: 76 },
    { name: 'Hub USB-C Premium', sku: 'SKU-1054', price: 119.90, stock: 2 },
    { name: 'Fonte 12V 5A', sku: 'SKU-1088', price: 59.90, stock: 3 }
  ]
};

const chartDefaults = () => {
  if (!window.Chart) return;

  Chart.defaults.font.family = 'Inter, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif';
  Chart.defaults.color = '#6E7F9D';
  Chart.defaults.plugins.legend.labels.usePointStyle = true;
  Chart.defaults.plugins.tooltip.backgroundColor = 'rgba(14,27,51,.92)';
  Chart.defaults.plugins.tooltip.padding = 12;
  Chart.defaults.plugins.tooltip.cornerRadius = 14;
};

const createGradient = (ctx, colorStart, colorEnd) => {
  const gradient = ctx.createLinearGradient(0, 0, 0, 220);
  gradient.addColorStop(0, colorStart);
  gradient.addColorStop(1, colorEnd);
  return gradient;
};

const renderFinanceCards = () => {
  const grid = document.querySelector('#financeGrid');
  if (!grid) return;

  grid.innerHTML = state.finance.map(item => `
    <article class="metric-card" style="--accent: ${item.accent}; --accent-bg: ${item.bg};">
      <span>${item.label}</span>
      <strong>${money.format(item.value)}</strong>
      <small>${item.note}</small>
    </article>
  `).join('');
};

const renderLatestSales = () => {
  const list = document.querySelector('#latestSalesList');
  if (!list) return;

  list.innerHTML = state.latestSales.map(sale => `
    <button class="list-row" data-demo-toast="Venda de ${sale.customer}">
      <div class="row-left">
        <span class="row-icon">✓</span>
        <div>
          <span class="row-title">${sale.customer}</span>
          <span class="row-subtitle">${sale.method} • ${sale.time}</span>
        </div>
      </div>
      <div>
        <span class="row-amount">${money.format(sale.amount)}</span>
        <span class="row-badge">Aprovada</span>
      </div>
    </button>
  `).join('');
};

const renderTopProducts = () => {
  const list = document.querySelector('#topProductsList');
  if (!list) return;

  list.innerHTML = state.topProducts.map(product => `
    <div class="list-row">
      <div class="row-left">
        <span class="row-icon">▦</span>
        <div>
          <span class="row-title">${product.name}</span>
          <span class="row-subtitle">${product.qty} vendidas</span>
        </div>
      </div>
      <span class="row-amount">${money.format(product.amount)}</span>
    </div>
  `).join('');
};

const renderLowStock = () => {
  const list = document.querySelector('#lowStockList');
  if (!list) return;

  list.innerHTML = state.lowStock.map(product => `
    <div class="list-row">
      <div class="row-left">
        <span class="row-icon">!</span>
        <div>
          <span class="row-title">${product.name}</span>
          <span class="row-subtitle">Repor estoque</span>
        </div>
      </div>
      <span class="row-badge">${product.qty}</span>
    </div>
  `).join('');
};

const renderCatalog = () => {
  const list = document.querySelector('#productsCatalogList');
  if (!list) return;

  list.innerHTML = state.catalog.map(product => `
    <button class="list-row" data-demo-toast="${product.name}">
      <div class="row-left">
        <span class="row-icon">▦</span>
        <div>
          <span class="row-title">${product.name}</span>
          <span class="row-subtitle">${product.sku} • Estoque: ${product.stock}</span>
        </div>
      </div>
      <span class="row-amount">${money.format(product.price)}</span>
    </button>
  `).join('');
};

const renderCharts = () => {
  if (!window.Chart) return;

  chartDefaults();

  const hourlyCanvas = document.querySelector('#hourlySalesChart');
  if (hourlyCanvas) {
    const ctx = hourlyCanvas.getContext('2d');
    new Chart(ctx, {
      type: 'line',
      data: {
        labels: ['08h', '09h', '10h', '11h', '12h', '13h', '14h', '15h', '16h', '17h'],
        datasets: [{
          label: 'Vendas',
          data: [620, 980, 1450, 1280, 870, 1120, 1580, 1840, 1390, 1770],
          fill: true,
          tension: .42,
          borderWidth: 3,
          borderColor: '#1768D5',
          pointRadius: 0,
          pointHoverRadius: 5,
          backgroundColor: createGradient(ctx, 'rgba(23,104,213,.25)', 'rgba(23,104,213,0)')
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { display: false },
          tooltip: {
            callbacks: {
              label: context => money.format(context.raw)
            }
          }
        },
        scales: {
          x: {
            grid: { display: false },
            border: { display: false }
          },
          y: {
            beginAtZero: true,
            border: { display: false },
            grid: { color: 'rgba(12,58,130,.08)' },
            ticks: {
              callback: value => `R$ ${Number(value / 1000).toFixed(1)}k`
            }
          }
        }
      }
    });
  }

  const paymentCanvas = document.querySelector('#paymentChart');
  if (paymentCanvas) {
    new Chart(paymentCanvas.getContext('2d'), {
      type: 'doughnut',
      data: {
        labels: ['PIX', 'Cartão', 'Dinheiro'],
        datasets: [{
          data: [44, 42, 14],
          backgroundColor: ['#12BFA2', '#1768D5', '#F7B731'],
          borderWidth: 0,
          hoverOffset: 5
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        cutout: '68%',
        plugins: {
          legend: {
            position: 'bottom',
            labels: {
              boxWidth: 8,
              boxHeight: 8,
              padding: 14
            }
          }
        }
      }
    });
  }

  const weeklyCanvas = document.querySelector('#weeklyChart');
  if (weeklyCanvas) {
    const ctx = weeklyCanvas.getContext('2d');
    new Chart(ctx, {
      type: 'bar',
      data: {
        labels: ['S', 'T', 'Q', 'Q', 'S', 'S', 'D'],
        datasets: [{
          label: 'Semana',
          data: [5200, 6100, 4800, 7900, 8742, 6900, 4300],
          borderRadius: 12,
          backgroundColor: createGradient(ctx, 'rgba(23,104,213,.92)', 'rgba(25,183,216,.42)')
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: { legend: { display: false } },
        scales: {
          x: {
            grid: { display: false },
            border: { display: false }
          },
          y: {
            display: false,
            beginAtZero: true
          }
        }
      }
    });
  }

  const monthlyCanvas = document.querySelector('#monthlyChart');
  if (monthlyCanvas) {
    const ctx = monthlyCanvas.getContext('2d');
    new Chart(ctx, {
      type: 'line',
      data: {
        labels: ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun'],
        datasets: [{
          label: 'Faturamento',
          data: [63000, 72000, 68000, 84000, 91000, 103000],
          fill: true,
          tension: .42,
          borderWidth: 3,
          borderColor: '#1768D5',
          pointRadius: 0,
          backgroundColor: createGradient(ctx, 'rgba(23,104,213,.22)', 'rgba(25,183,216,0)')
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { display: false },
          tooltip: {
            callbacks: {
              label: context => money.format(context.raw)
            }
          }
        },
        scales: {
          x: {
            grid: { display: false },
            border: { display: false }
          },
          y: {
            border: { display: false },
            grid: { color: 'rgba(12,58,130,.08)' },
            ticks: {
              callback: value => `R$ ${Number(value / 1000).toFixed(0)}k`
            }
          }
        }
      }
    });
  }
};

const toast = (() => {
  const element = document.querySelector('#toast');
  let timeout;

  return message => {
    if (!element) return;

    clearTimeout(timeout);
    element.textContent = message;
    element.classList.add('show');

    timeout = setTimeout(() => {
      element.classList.remove('show');
    }, 2200);
  };
})();

const activateTab = tab => {
  document.querySelectorAll('.page').forEach(page => {
    page.classList.toggle('page-active', page.dataset.page === tab);
  });

  document.querySelectorAll('.nav-item').forEach(item => {
    item.classList.toggle('active', item.dataset.tab === tab);
  });

  const screen = document.querySelector('.app-screen');
  if (screen) screen.scrollTo({ top: 0, behavior: 'smooth' });
};

const bindNavigation = () => {
  document.querySelectorAll('[data-tab]').forEach(button => {
    button.addEventListener('click', () => activateTab(button.dataset.tab));
  });

  document.querySelectorAll('[data-tab-target]').forEach(button => {
    button.addEventListener('click', () => activateTab(button.dataset.tabTarget));
  });
};

const bindDemoActions = () => {
  document.body.addEventListener('click', event => {
    const target = event.target.closest('[data-demo-toast]');
    if (!target) return;

    toast(target.dataset.demoToast);
  });
};

const boot = () => {
  renderFinanceCards();
  renderLatestSales();
  renderTopProducts();
  renderLowStock();
  renderCatalog();
  renderCharts();
  bindNavigation();
  bindDemoActions();
};

document.addEventListener('DOMContentLoaded', boot);
