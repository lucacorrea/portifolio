<?php

declare(strict_types=1);

use App\Core\PageContext;

require_once __DIR__ . '/bootstrap.php';

$frontendContext = PageContext::requireAuthenticatedFrontendContext();
$pageKey = 'pessoas-prontuarios';
?>
<!doctype html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Perfil familiar demonstrativo do SIGAS Coari.">
    <title>SIGAS Coari — Prontuário ANEXO ANX-000125</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">
    <link href="assets/css/module-navigation.css?v=<?= (int) filemtime(__DIR__ . '/assets/css/module-navigation.css') ?>" rel="stylesheet">
</head>
<body data-page="registro" data-module="protecao-social-basica">
    <div class="app-shell module-shell module-shell--basic" data-module-shell data-menu-environment="protecao-social-basica">
        <?php $menuSurface = 'sidebar'; $menuPageKey = $pageKey; require __DIR__ . '/frontend/modules/protecao-social-basica/menu.php'; ?>
        <div class="app-main module-main">
            <?php require __DIR__ . '/frontend/layouts/module-topbar.php'; ?>

            <main class="app-content">
                <a class="back-link" href="pessoas.php"><i class="bi bi-arrow-left"></i>Voltar para pessoas e prontuários</a>
                

                <header class="profile-header">
                    <div class="profile-avatar" aria-hidden="true">MS</div>
                    <div class="profile-main">
                        <div class="profile-code">Prontuário ANEXO · ANX-000125</div>
                        <h1>Maria da Silva</h1>
                        <div class="profile-meta"><span><i class="bi bi-person-vcard"></i> CPF: ***.456.789-**</span><span><i class="bi bi-upc-scan"></i> NIS: 12345678900</span><span class="status-badge status-success"><i class="bi bi-check-circle"></i>Beneficiária ativa</span><span class="source-badge source-linked"><i class="bi bi-link-45deg"></i>SIGAS + referência SEMTH</span><span><i class="bi bi-clock-history"></i> Atualizado em 18/06/2026</span></div>
                    </div>
                    <div class="profile-actions">
                        <button class="btn btn-light" type="button" data-bs-toggle="modal" data-bs-target="#occurrenceModal"><i class="bi bi-exclamation-circle"></i><span class="optional">Adicionar ocorrência</span></button>
                        <button class="btn btn-light" type="button" data-bs-toggle="modal" data-bs-target="#deliveryModal"><i class="bi bi-basket2"></i>Registrar entrega</button>
                        <a class="btn btn-primary" href="cadastro-anexo.php?modo=editar"><i class="bi bi-pencil"></i>Editar Cadastro ANEXO</a>
                        <div class="dropdown"><button class="btn btn-light btn-icon" type="button" data-bs-toggle="dropdown" aria-label="Mais ações"><i class="bi bi-three-dots"></i></button><ul class="dropdown-menu dropdown-menu-end"><li><button class="dropdown-item" type="button" data-demo-action="imprimir ficha"><i class="bi bi-printer me-2"></i>Imprimir ficha</button></li><li><button class="dropdown-item" type="button" data-demo-action="exportar histórico"><i class="bi bi-download me-2"></i>Exportar histórico</button></li><li><hr class="dropdown-divider"></li><li><button class="dropdown-item text-danger" type="button" data-confirm-action="Bloquear temporariamente este registro?"><i class="bi bi-lock me-2"></i>Bloquear registro</button></li></ul></div>
                    </div>
                </header>

                <section class="record-ownership-card" data-record-ownership aria-label="Origem e propriedade dos dados">
                    <div class="record-ownership-main"><span class="record-ownership-icon"><i class="bi bi-link-45deg"></i></span><div><div class="card-kicker">Origem do registro</div><h2>Cadastro SIGAS vinculado a uma referência SEMTH</h2><p>Os dados operacionais desta ficha pertencem ao SIGAS. O sistema antigo é consultado apenas para conferência e prevenção de duplicidade.</p></div></div>
                    <div class="ownership-sources">
                        <div class="ownership-source local"><span><i class="bi bi-database-check"></i>Base SIGAS</span><strong>PS-018452</strong><small>Leitura e edição autorizadas conforme perfil</small></div>
                        <div class="ownership-source legacy"><span><i class="bi bi-database-lock"></i>Base SEMTH</span><strong>SEMTH-009842</strong><small>Somente leitura · consultado em <span data-integration-time>—</span></small></div>
                    </div>
                    <a class="btn btn-light btn-sm" href="integracao-semth.php#consulta"><i class="bi bi-arrow-left-right"></i>Comparar dados</a>
                </section>

                <section class="profile-summary-grid" aria-label="Resumo do prontuário">
                    <article class="profile-summary-item"><i class="bi bi-people"></i><strong>5 integrantes</strong><span>Composição familiar</span></article>
                    <article class="profile-summary-item"><i class="bi bi-cash-stack"></i><strong>R$ 1.420,00</strong><span>Renda familiar</span></article>
                    <article class="profile-summary-item"><i class="bi bi-pie-chart"></i><strong>R$ 284,00</strong><span>Renda per capita</span></article>
                    <article class="profile-summary-item"><i class="bi bi-balloon-heart"></i><strong>2 crianças</strong><span>Menores de 12 anos</span></article>
                    <article class="profile-summary-item"><i class="bi bi-person-walking"></i><strong>1 idoso</strong><span>60 anos ou mais</span></article>
                    <article class="profile-summary-item"><i class="bi bi-universal-access"></i><strong>1 pessoa</strong><span>Com deficiência</span></article>
                    <article class="profile-summary-item"><i class="bi bi-bag-check"></i><strong>10/06/2026</strong><span>Última entrega</span></article>
                    <article class="profile-summary-item"><i class="bi bi-calendar2-check"></i><strong>Setembro/2026</strong><span>Próxima revisão</span></article>
                </section>

                <section class="status-summary" aria-label="Situações do registro">
                    <div class="status-summary-item"><span>Situação cadastral</span><strong class="status-badge status-success"><i class="bi bi-check-circle"></i>Regular</strong></div>
                    <div class="status-summary-item"><span>Situação no programa</span><strong class="status-badge status-success"><i class="bi bi-check-circle"></i>Beneficiária ativa</strong></div>
                    <div class="status-summary-item"><span>Entrega de junho</span><strong class="status-badge status-success"><i class="bi bi-bag-check"></i>Recebida</strong></div>
                </section>

                <section class="profile-tabs-wrap" data-tabs-group>
                    <nav class="module-tabs" aria-label="Seções do perfil familiar">
                        <button class="module-tab active" type="button" data-tab-target="summary" aria-current="page">Resumo</button>
                        <button class="module-tab" type="button" data-tab-target="family">Composição familiar</button>
                        <button class="module-tab" type="button" data-tab-target="address">Endereço</button>
                        <button class="module-tab" type="button" data-tab-target="documents">Documentos</button>
                        <button class="module-tab" type="button" data-tab-target="assessment">Avaliação Social</button>
                        <button class="module-tab" type="button" data-tab-target="deliveries">Entregas</button>
                        <button class="module-tab" type="button" data-tab-target="occurrences">Ocorrências</button>
                        <button class="module-tab" type="button" data-tab-target="history">Histórico</button>
                    </nav>

                    <div class="dashboard-grid mt-3" data-tab-panel="summary">
                        <div class="col-span-8 side-stack">
                            <article class="content-card">
                                <div class="card-heading"><div><div class="card-kicker">Identificação</div><h2>Dados pessoais</h2></div><button class="btn btn-light btn-sm" type="button" data-bs-toggle="modal" data-bs-target="#editRegistrationModal"><i class="bi bi-pencil"></i>Editar</button></div>
                                <div class="info-grid">
                                    <div><div class="info-row"><span>Nome completo</span><strong>Maria da Silva</strong></div><div class="info-row"><span>CPF</span><strong>***.456.789-**</strong></div><div class="info-row"><span>RG</span><strong>12.345.678-9</strong></div><div class="info-row"><span>NIS</span><strong>12345678900</strong></div></div>
                                    <div><div class="info-row"><span>Data de nascimento</span><strong>14/03/1986</strong></div><div class="info-row"><span>Telefone</span><strong>(97) 9 9123-4567</strong></div><div class="info-row"><span>E-mail</span><strong>maria.exemplo@email.com</strong></div><div class="info-row"><span>Responsável pelo cadastro</span><strong>Maria Oliveira</strong></div></div>
                                </div>
                            </article>

                            <article class="content-card">
                                <div class="card-heading"><div><div class="card-kicker">Núcleo familiar</div><h2>Composição familiar resumida</h2></div><button class="btn btn-light btn-sm" type="button" data-bs-toggle="modal" data-bs-target="#editRegistrationModal"><i class="bi bi-person-plus"></i>Gerenciar</button></div>
                                <div class="family-member"><span class="mini-avatar">MS</span><div class="item-main"><strong>Maria da Silva</strong><span>Responsável familiar · 40 anos · Renda R$ 920,00</span></div><span class="status-badge status-success">Responsável</span></div>
                                <div class="family-member"><span class="mini-avatar">PS</span><div class="item-main"><strong>Paulo da Silva</strong><span>Cônjuge · 43 anos · Renda R$ 500,00</span></div><span class="status-badge status-neutral">Cônjuge</span></div>
                                <div class="family-member"><span class="mini-avatar">LS</span><div class="item-main"><strong>Larissa da Silva</strong><span>Filha · 10 anos · Estudante</span></div><span class="status-badge status-info">Criança</span></div>
                                <div class="family-member"><span class="mini-avatar">GS</span><div class="item-main"><strong>Gabriel da Silva</strong><span>Filho · 6 anos · Estudante</span></div><span class="status-badge status-info">Criança</span></div>
                                <div class="family-member"><span class="mini-avatar">AS</span><div class="item-main"><strong>Antônia Souza</strong><span>Mãe · 67 anos · Pessoa com deficiência</span></div><span class="status-badge status-warning">Acompanhamento</span></div>
                            </article>

                            <article class="content-card">
                                <div class="card-heading"><div><div class="card-kicker">Localização</div><h2>Endereço</h2></div><span class="status-badge status-success"><i class="bi bi-check-circle"></i>Confirmado</span></div>
                                <div class="info-grid"><div><div class="info-row"><span>Zona</span><strong>Urbana</strong></div><div class="info-row"><span>Rua</span><strong>Rua das Acácias</strong></div><div class="info-row"><span>Número</span><strong>125</strong></div><div class="info-row"><span>Bairro</span><strong>São Sebastião</strong></div></div><div><div class="info-row"><span>CEP</span><strong>69460-000</strong></div><div class="info-row"><span>Comunidade</span><strong>Não se aplica</strong></div><div class="info-row"><span>Ponto de referência</span><strong>Próximo à escola municipal</strong></div><div class="info-row"><span>Polo de entrega</span><strong>Polo São Sebastião</strong></div></div></div>
                            </article>

                            <article class="content-card">
                                <div class="card-heading"><div><div class="card-kicker">Condições familiares</div><h2>Informações socioeconômicas</h2></div><span class="status-badge status-info">Avaliada em 05/06/2026</span></div>
                                <div class="info-grid"><div><div class="info-row"><span>Renda familiar</span><strong>R$ 1.420,00</strong></div><div class="info-row"><span>Renda per capita</span><strong>R$ 284,00</strong></div><div class="info-row"><span>Tipo de moradia</span><strong>Própria</strong></div><div class="info-row"><span>Situação de trabalho</span><strong>Trabalho informal</strong></div></div><div><div class="info-row"><span>Crianças</span><strong>2</strong></div><div class="info-row"><span>Idosos</span><strong>1</strong></div><div class="info-row"><span>Pessoas com deficiência</span><strong>1</strong></div><div class="info-row"><span>Prioridade social</span><strong>Média</strong></div></div></div>
                                <div class="alert-soft warning mt-3"><i class="bi bi-exclamation-triangle"></i><div><strong>Pendência documental:</strong> atualizar o comprovante de residência até 30/06/2026.</div></div>
                            </article>

                            <article class="content-card table-card">
                                <div class="table-toolbar"><div><h2 class="fs-6 mb-1">Histórico de entregas</h2><div class="table-toolbar-info">Últimas competências registradas</div></div><button class="btn btn-light btn-sm" type="button" data-demo-action="exportar entregas"><i class="bi bi-download"></i>Exportar</button></div>
                                <div class="table-responsive"><table class="data-table"><thead><tr><th>Competência</th><th>Data</th><th>Local</th><th>Recebedor</th><th>Servidor</th><th>Situação</th><th>Comprovante</th></tr></thead><tbody><tr><td>Junho/2026</td><td>10/06/2026</td><td>Polo São Sebastião</td><td>Maria da Silva</td><td>Maria Oliveira</td><td><span class="status-badge status-success">Recebida</span></td><td><button class="btn btn-light btn-sm" type="button" data-demo-action="abrir comprovante"><i class="bi bi-file-earmark-check"></i>Visualizar</button></td></tr><tr><td>Maio/2026</td><td>11/05/2026</td><td>Polo São Sebastião</td><td>Paulo da Silva</td><td>João Almeida</td><td><span class="status-badge status-success">Recebida</span></td><td><button class="btn btn-light btn-sm" type="button" data-demo-action="abrir comprovante"><i class="bi bi-file-earmark-check"></i>Visualizar</button></td></tr><tr><td>Abril/2026</td><td>12/04/2026</td><td>Polo São Sebastião</td><td>Maria da Silva</td><td>Maria Oliveira</td><td><span class="status-badge status-success">Recebida</span></td><td><button class="btn btn-light btn-sm" type="button" data-demo-action="abrir comprovante"><i class="bi bi-file-earmark-check"></i>Visualizar</button></td></tr></tbody></table></div>
                            </article>
                        </div>

                        <aside class="col-span-4 side-stack" aria-label="Informações complementares">
                            <article class="content-card">
                                <div class="card-heading"><div><div class="card-kicker">Acompanhamento</div><h2>Alertas e pendências</h2></div><span class="status-badge status-warning">2 itens</span></div>
                                <div class="notice-list"><div class="notice-item"><span class="notice-icon warning"><i class="bi bi-file-earmark-x"></i></span><div class="item-main"><strong>Comprovante de residência</strong><span>Vencido há 14 dias. Solicitar atualização.</span></div></div><div class="notice-item"><span class="notice-icon info"><i class="bi bi-calendar2-check"></i></span><div class="item-main"><strong>Revisão cadastral</strong><span>Programada para setembro de 2026.</span></div></div></div>
                            </article>

                            <article class="content-card">
                                <div class="card-heading"><div><div class="card-kicker">Referências</div><h2>Vínculos territoriais</h2></div></div>
                                <div class="reference-card"><span>Unidade de referência</span><strong>CRAS 1 — São Sebastião</strong></div>
                                <div class="reference-card"><span>Técnica responsável</span><strong>Maria Oliveira — Assistente Social</strong></div>
                                <div class="reference-card"><span>Polo de entrega</span><strong>Polo São Sebastião</strong></div>
                                <div class="reference-card"><span>Próxima revisão</span><strong>Setembro de 2026</strong></div>
                            </article>

                            <article class="content-card">
                                <div class="card-heading"><div><div class="card-kicker">Movimentações</div><h2>Linha do tempo recente</h2></div><button class="btn btn-light btn-sm" type="button" data-demo-action="ver histórico completo">Ver tudo</button></div>
                                <div class="timeline">
                                    <div class="timeline-item"><span class="timeline-dot"></span><div class="timeline-content"><strong>Cadastro atualizado</strong><span>18/06/2026 às 14:22 · Maria Oliveira</span></div></div>
                                    <div class="timeline-item"><span class="timeline-dot"></span><div class="timeline-content"><strong>Entrega confirmada</strong><span>10/06/2026 às 09:18 · Polo São Sebastião</span></div></div>
                                    <div class="timeline-item"><span class="timeline-dot"></span><div class="timeline-content"><strong>Avaliação social concluída</strong><span>05/06/2026 às 11:40 · CRAS 1</span></div></div>
                                    <div class="timeline-item"><span class="timeline-dot"></span><div class="timeline-content"><strong>Documento anexado</strong><span>02/06/2026 às 16:05 · Declaração socioeconômica</span></div></div>
                                    <div class="timeline-item"><span class="timeline-dot"></span><div class="timeline-content"><strong>Alteração de polo</strong><span>28/05/2026 às 10:30 · Polo Centro para São Sebastião</span></div></div>
                                </div>
                            </article>

                            <article class="content-card restricted-overlay">
                                <div class="card-heading"><div><div class="card-kicker">Área técnica</div><h2>Parecer reservado</h2></div></div><p class="text-secondary small mb-0">Conteúdo protegido conforme o perfil de acesso do usuário.</p>
                            </article>
                        </aside>
                    </div>

                    <div class="content-card mt-3" data-tab-panel="family" hidden><div class="state-panel show"><i class="bi bi-people"></i><h3>Composição familiar</h3><p>Conteúdo detalhado disponível no painel de edição demonstrativo.</p><button class="btn btn-primary btn-sm mt-3" type="button" data-bs-toggle="modal" data-bs-target="#editRegistrationModal">Editar composição</button></div></div>
                    <div class="content-card mt-3" data-tab-panel="address" hidden><div class="state-panel show"><i class="bi bi-geo-alt"></i><h3>Endereço e território</h3><p>Dados urbanos, rurais, comunidade, referências e polo de entrega.</p></div></div>
                    <div class="content-card mt-3" data-tab-panel="documents" hidden><div class="document-grid"><div class="document-upload"><i class="bi bi-file-earmark-check"></i><strong>CPF</strong><span>Documento validado</span></div><div class="document-upload"><i class="bi bi-file-earmark-check"></i><strong>RG</strong><span>Documento validado</span></div><div class="document-upload"><i class="bi bi-file-earmark-check"></i><strong>NIS</strong><span>Documento validado</span></div><div class="document-upload"><i class="bi bi-file-earmark-excel"></i><strong>Comprovante de residência</strong><span>Atualização necessária</span></div><div class="document-upload"><i class="bi bi-file-earmark-check"></i><strong>Declaração</strong><span>Documento validado</span></div><div class="document-upload"><i class="bi bi-cloud-arrow-up"></i><strong>Outros documentos</strong><span>Clique para anexar</span></div></div></div>
                    <div class="content-card mt-3" data-tab-panel="assessment" hidden><div class="state-panel show"><i class="bi bi-clipboard2-pulse"></i><h3>Avaliação social</h3><p>Última avaliação concluída em 05/06/2026 com prioridade social média.</p></div></div>
                    <div class="content-card mt-3" data-tab-panel="deliveries" hidden><div class="state-panel show"><i class="bi bi-basket2"></i><h3>Entregas mensais</h3><p>Três competências recentes confirmadas sem inconsistências.</p></div></div>
                    <div class="content-card mt-3" data-tab-panel="occurrences" hidden><div class="state-panel show"><i class="bi bi-check2-circle"></i><h3>Nenhuma ocorrência crítica</h3><p>Há apenas uma pendência documental em acompanhamento.</p></div></div>
                    <div class="content-card mt-3" data-tab-panel="history" hidden><div class="state-panel show"><i class="bi bi-clock-history"></i><h3>Histórico completo</h3><p>Movimentações administrativas e técnicas do cadastro familiar.</p></div></div>
                </section>
            </main>

            <footer class="app-footer"><span>Dados demonstrativos utilizados apenas para prototipação.</span><span>SIGAS Coari — SEMAS Coari/AM</span></footer>
        </div>
        <?php $menuSurface = 'mobile'; require __DIR__ . '/frontend/modules/protecao-social-basica/menu.php'; ?>
    </div>

    <div class="modal fade" id="editRegistrationModal" tabindex="-1" aria-labelledby="editRegistrationTitle" aria-hidden="true">
        <div class="modal-dialog modal-xl modal-dialog-centered modal-dialog-scrollable">
            <div class="modal-content">
                <div class="modal-header"><div><div class="eyebrow mb-1"><i class="bi bi-pencil-square"></i>Cadastro familiar</div><h2 class="modal-title fs-5" id="editRegistrationTitle">Editar família CM-000125</h2></div><div class="d-flex align-items-center gap-3"><span class="text-secondary small" id="stepProgressText">Etapa 1 de 6</span><button class="btn-close" type="button" data-bs-dismiss="modal" aria-label="Fechar"></button></div></div>
                <div class="modal-body">
                    <div class="form-stepper" aria-label="Etapas do formulário">
                        <div class="form-step active"><div class="form-step-number">1</div><span>Identificação</span></div>
                        <div class="form-step"><div class="form-step-number">2</div><span>Família</span></div>
                        <div class="form-step"><div class="form-step-number">3</div><span>Endereço</span></div>
                        <div class="form-step"><div class="form-step-number">4</div><span>Socioeconômica</span></div>
                        <div class="form-step"><div class="form-step-number">5</div><span>Documentos</span></div>
                        <div class="form-step"><div class="form-step-number">6</div><span>Revisão</span></div>
                    </div>

                    <section class="form-panel active">
                        <h3 class="form-section-title">Identificação da responsável familiar</h3><p class="form-section-subtitle">Confirme os dados pessoais e os canais de contato.</p>
                        <div class="form-grid"><div class="field-6"><label class="form-label" for="editName">Nome completo</label><input class="form-control" id="editName" type="text" value="Maria da Silva" required></div><div class="field-3"><label class="form-label" for="editCpf">CPF</label><input class="form-control" id="editCpf" type="text" value="***.456.789-**" required></div><div class="field-3"><label class="form-label" for="editRg">RG</label><input class="form-control" id="editRg" type="text" value="12.345.678-9" required></div><div class="field-4"><label class="form-label" for="editNis">NIS</label><input class="form-control" id="editNis" type="text" value="12345678900" required></div><div class="field-4"><label class="form-label" for="editBirth">Data de nascimento</label><input class="form-control" id="editBirth" type="date" value="1986-03-14" required></div><div class="field-4"><label class="form-label" for="editPhone">Telefone</label><input class="form-control" id="editPhone" type="tel" value="(97) 9 9123-4567" required></div><div class="field-6"><label class="form-label" for="editEmail">E-mail</label><input class="form-control" id="editEmail" type="email" value="maria.exemplo@email.com"></div><div class="field-6"><label class="form-label" for="editStatus">Situação cadastral</label><select class="form-select" id="editStatus"><option>Regular</option><option>Pendente</option><option>Bloqueado</option></select></div></div>
                    </section>

                    <section class="form-panel">
                        <div class="d-flex justify-content-between align-items-start gap-3 mb-3"><div><h3 class="form-section-title">Composição familiar</h3><p class="form-section-subtitle mb-0">Adicione, remova e atualize os integrantes do núcleo familiar.</p></div><button class="btn btn-primary btn-sm" type="button" data-add-member><i class="bi bi-person-plus"></i>Adicionar integrante</button></div>
                        <div id="familyMembersEditor">
                            <div class="member-editor"><div class="member-editor-head"><strong class="member-number">Integrante 1</strong><span class="status-badge status-success">Responsável</span></div><div class="form-grid"><div class="field-6"><label class="form-label">Nome</label><input class="form-control" type="text" value="Maria da Silva"></div><div class="field-3"><label class="form-label">Parentesco</label><select class="form-select"><option>Responsável</option></select></div><div class="field-3"><label class="form-label">Data de nascimento</label><input class="form-control" type="date" value="1986-03-14"></div><div class="field-3"><label class="form-label">CPF</label><input class="form-control" type="text" value="***.456.789-**"></div><div class="field-3"><label class="form-label">NIS</label><input class="form-control" type="text" value="12345678900"></div><div class="field-3"><label class="form-label">Renda</label><input class="form-control" type="text" value="R$ 920,00"></div><div class="field-3"><label class="form-label">Ocupação</label><input class="form-control" type="text" value="Autônoma"></div></div></div>
                            <div class="member-editor"><div class="member-editor-head"><strong class="member-number">Integrante 2</strong><button type="button" class="btn btn-sm btn-light text-danger" data-remove-member><i class="bi bi-trash"></i>Remover</button></div><div class="form-grid"><div class="field-6"><label class="form-label">Nome</label><input class="form-control" type="text" value="Paulo da Silva"></div><div class="field-3"><label class="form-label">Parentesco</label><select class="form-select"><option>Cônjuge</option></select></div><div class="field-3"><label class="form-label">Data de nascimento</label><input class="form-control" type="date" value="1983-08-22"></div><div class="field-3"><label class="form-label">CPF</label><input class="form-control" type="text" value="***.654.321-**"></div><div class="field-3"><label class="form-label">NIS</label><input class="form-control" type="text" value="10987654321"></div><div class="field-3"><label class="form-label">Renda</label><input class="form-control" type="text" value="R$ 500,00"></div><div class="field-3"><label class="form-label">Ocupação</label><input class="form-control" type="text" value="Serviços gerais"></div></div></div>
                        </div>
                    </section>

                    <section class="form-panel">
                        <h3 class="form-section-title">Endereço e território</h3><p class="form-section-subtitle">Informe a localização da residência e o polo de entrega de referência.</p>
                        <div class="form-grid"><div class="field-3"><label class="form-label" for="editZone">Zona</label><select class="form-select" id="editZone" required><option>Urbana</option><option>Rural</option></select></div><div class="field-3"><label class="form-label" for="editCep">CEP</label><input class="form-control" id="editCep" type="text" value="69460-000"></div><div class="field-4"><label class="form-label" for="editStreet">Rua</label><input class="form-control" id="editStreet" type="text" value="Rua das Acácias" required></div><div class="field-2"><label class="form-label" for="editNumber">Número</label><input class="form-control" id="editNumber" type="text" value="125"></div><div class="field-4"><label class="form-label" for="editDistrict">Bairro</label><input class="form-control" id="editDistrict" type="text" value="São Sebastião" required></div><div class="field-4"><label class="form-label" for="editCommunity">Comunidade</label><input class="form-control" id="editCommunity" type="text" placeholder="Para zona rural"></div><div class="field-4"><label class="form-label" for="editRiver">Rio ou lago</label><input class="form-control" id="editRiver" type="text" placeholder="Quando aplicável"></div><div class="field-8"><label class="form-label" for="editReference">Ponto de referência</label><input class="form-control" id="editReference" type="text" value="Próximo à escola municipal"></div><div class="field-4"><label class="form-label" for="editPole">Polo de entrega</label><select class="form-select" id="editPole" required><option>Polo São Sebastião</option><option>Polo Centro</option><option>Polo Itamarati</option><option>Polo Zona Rural</option></select></div></div>
                    </section>

                    <section class="form-panel">
                        <h3 class="form-section-title">Situação socioeconômica</h3><p class="form-section-subtitle">Atualize os indicadores usados na avaliação e no acompanhamento familiar.</p>
                        <div class="form-grid"><div class="field-3"><label class="form-label" for="familyIncome">Renda familiar</label><input class="form-control" id="familyIncome" type="text" value="R$ 1.420,00" required></div><div class="field-3"><label class="form-label" for="perCapitaIncome">Renda per capita</label><input class="form-control" id="perCapitaIncome" type="text" value="R$ 284,00" required></div><div class="field-3"><label class="form-label" for="housingType">Tipo de moradia</label><select class="form-select" id="housingType"><option>Própria</option><option>Alugada</option><option>Cedida</option><option>Ocupação</option></select></div><div class="field-3"><label class="form-label" for="workStatus">Situação de trabalho</label><select class="form-select" id="workStatus"><option>Trabalho informal</option><option>Emprego formal</option><option>Desempregado</option><option>Aposentado</option></select></div><div class="field-3"><label class="form-label" for="childrenCount">Quantidade de crianças</label><input class="form-control" id="childrenCount" type="number" min="0" value="2"></div><div class="field-3"><label class="form-label" for="elderlyCount">Quantidade de idosos</label><input class="form-control" id="elderlyCount" type="number" min="0" value="1"></div><div class="field-3"><label class="form-label" for="disabledCount">Pessoas com deficiência</label><input class="form-control" id="disabledCount" type="number" min="0" value="1"></div><div class="field-3"><label class="form-label" for="socialPriority">Prioridade social</label><select class="form-select" id="socialPriority"><option>Média</option><option>Alta</option><option>Baixa</option></select></div><div class="field-12"><label class="form-label" for="socialNotes">Observações</label><textarea class="form-control" id="socialNotes" rows="4">Família acompanhada pelo CRAS 1. Manter atenção à atualização documental e à próxima revisão cadastral.</textarea></div></div>
                    </section>

                    <section class="form-panel">
                        <h3 class="form-section-title">Documentos</h3><p class="form-section-subtitle">Selecione os blocos para simular o envio ou a substituição dos arquivos.</p>
                        <div class="document-grid"><button class="document-upload" type="button"><i class="bi bi-person-vcard"></i><strong>CPF</strong><span>Arquivo validado · substituir</span></button><button class="document-upload" type="button"><i class="bi bi-card-heading"></i><strong>RG</strong><span>Arquivo validado · substituir</span></button><button class="document-upload" type="button"><i class="bi bi-upc-scan"></i><strong>NIS</strong><span>Arquivo validado · substituir</span></button><button class="document-upload" type="button"><i class="bi bi-house-check"></i><strong>Comprovante de residência</strong><span>Documento vencido · atualizar</span></button><button class="document-upload" type="button"><i class="bi bi-file-earmark-text"></i><strong>Declaração</strong><span>Arquivo validado · substituir</span></button><button class="document-upload" type="button"><i class="bi bi-cloud-arrow-up"></i><strong>Outros documentos</strong><span>Clique para anexar</span></button></div>
                    </section>

                    <section class="form-panel">
                        <h3 class="form-section-title">Revisão do cadastro</h3><p class="form-section-subtitle">Confira as informações principais antes de concluir a atualização.</p>
                        <div class="review-block"><h4>Identificação</h4><div class="info-grid"><div class="info-row"><span>Responsável</span><strong>Maria da Silva</strong></div><div class="info-row"><span>CPF</span><strong>***.456.789-**</strong></div><div class="info-row"><span>NIS</span><strong>12345678900</strong></div><div class="info-row"><span>Telefone</span><strong>(97) 9 9123-4567</strong></div></div></div>
                        <div class="review-block"><h4>Família e renda</h4><div class="info-grid"><div class="info-row"><span>Integrantes</span><strong>5 pessoas</strong></div><div class="info-row"><span>Renda familiar</span><strong>R$ 1.420,00</strong></div><div class="info-row"><span>Renda per capita</span><strong>R$ 284,00</strong></div><div class="info-row"><span>Prioridade</span><strong>Média</strong></div></div></div>
                        <div class="review-block"><h4>Endereço e programa</h4><div class="info-grid"><div class="info-row"><span>Bairro</span><strong>São Sebastião</strong></div><div class="info-row"><span>Polo</span><strong>Polo São Sebastião</strong></div><div class="info-row"><span>Situação cadastral</span><strong>Regular</strong></div><div class="info-row"><span>Situação no programa</span><strong>Beneficiária ativa</strong></div></div></div>
                        <div class="alert-soft warning"><i class="bi bi-exclamation-triangle"></i><div>O comprovante de residência está marcado para atualização. A conclusão será permitida com registro de pendência.</div></div>
                    </section>
                </div>
                <div class="modal-footer justify-content-between"><button class="btn btn-light" type="button" data-save-draft><i class="bi bi-save"></i>Salvar rascunho</button><div class="d-flex gap-2"><button class="btn btn-light" type="button" data-step-prev><i class="bi bi-arrow-left"></i>Voltar</button><button class="btn btn-primary" type="button" data-step-next>Continuar<i class="bi bi-arrow-right"></i></button><button class="btn btn-primary d-none" type="button" data-step-finish><i class="bi bi-check2-circle"></i>Concluir cadastro</button></div></div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="deliveryModal" tabindex="-1" aria-labelledby="deliveryTitle" aria-hidden="true"><div class="modal-dialog modal-dialog-centered"><div class="modal-content"><div class="modal-header"><div><div class="eyebrow mb-1"><i class="bi bi-basket2"></i>Comida na Mesa</div><h2 class="modal-title fs-5" id="deliveryTitle">Registrar entrega</h2></div><button class="btn-close" type="button" data-bs-dismiss="modal" aria-label="Fechar"></button></div><div class="modal-body"><div class="alert-soft success mb-3"><i class="bi bi-check-circle"></i><div>Família ativa e apta para a competência selecionada.</div></div><div class="mb-3"><label class="form-label" for="deliveryMonth">Competência</label><select class="form-select" id="deliveryMonth" required><option>Junho de 2026</option><option>Julho de 2026</option></select></div><div class="mb-3"><label class="form-label" for="deliveryReceiver">Recebedor</label><input class="form-control" id="deliveryReceiver" type="text" value="Maria da Silva" required></div><div><label class="form-label" for="deliveryObservation">Observações</label><textarea class="form-control" id="deliveryObservation" rows="3"></textarea></div></div><div class="modal-footer"><button class="btn btn-light" type="button" data-bs-dismiss="modal">Cancelar</button><button class="btn btn-primary" type="button" data-submit-demo="Entrega registrada no histórico familiar."><i class="bi bi-check2-circle"></i>Confirmar entrega</button></div></div></div></div>

    <div class="modal fade" id="occurrenceModal" tabindex="-1" aria-labelledby="occurrenceTitle" aria-hidden="true"><div class="modal-dialog modal-dialog-centered"><div class="modal-content"><div class="modal-header"><div><div class="eyebrow mb-1"><i class="bi bi-exclamation-circle"></i>Acompanhamento familiar</div><h2 class="modal-title fs-5" id="occurrenceTitle">Adicionar ocorrência</h2></div><button class="btn-close" type="button" data-bs-dismiss="modal" aria-label="Fechar"></button></div><div class="modal-body"><div class="mb-3"><label class="form-label" for="occurrenceType">Tipo</label><select class="form-select" id="occurrenceType" required><option value="">Selecione</option><option>Pendência documental</option><option>Não comparecimento</option><option>Alteração familiar</option><option>Inconsistência cadastral</option></select></div><div><label class="form-label" for="occurrenceDescription">Descrição</label><textarea class="form-control" id="occurrenceDescription" rows="4" required></textarea></div></div><div class="modal-footer"><button class="btn btn-light" type="button" data-bs-dismiss="modal">Cancelar</button><button class="btn btn-primary" type="button" data-submit-demo="Ocorrência adicionada à linha do tempo."><i class="bi bi-check2"></i>Salvar ocorrência</button></div></div></div></div>

    <div class="modal fade" id="confirmationModal" tabindex="-1" aria-labelledby="confirmationTitle" aria-hidden="true"><div class="modal-dialog modal-dialog-centered modal-sm"><div class="modal-content"><div class="modal-body text-center p-4"><span class="notice-icon warning mx-auto mb-3"><i class="bi bi-exclamation-triangle"></i></span><h2 class="fs-5" id="confirmationTitle">Confirmar ação</h2><p class="text-secondary small" id="confirmationText">Deseja continuar?</p><div class="d-grid gap-2 mt-4"><button class="btn btn-primary" id="confirmActionButton" type="button">Confirmar</button><button class="btn btn-light" type="button" data-bs-dismiss="modal">Cancelar</button></div></div></div></div></div>

    <div class="toast-container position-fixed top-0 end-0 p-3" id="toastContainer"></div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/integration-demo.js"></script>
    <?= PageContext::script($frontendContext) ?>
    <script src="assets/js/app.js"></script>
    <script src="assets/js/module-navigation.js?v=<?= (int) filemtime(__DIR__ . '/assets/js/module-navigation.js') ?>"></script>
</body>
</html>

