<?php

declare(strict_types=1);

use App\Core\PageContext;

require_once __DIR__ . '/bootstrap.php';

$frontendContext = PageContext::requireAuthenticatedFrontendContext();
?>
<!doctype html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Rede socioassistencial do SIGAS Coari.">
    <title>SIGAS Coari — Unidades</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">
</head>
<body data-page="rede-de-unidades" data-module="planejamento-gestao">
    <div class="app-shell">
        <aside class="app-sidebar" id="appSidebar" aria-label="Menu principal"></aside>
        <div class="app-main">
            <header class="app-topbar" id="appTopbar"></header>
            <main class="app-content">
                <header class="page-header"><div><div class="eyebrow"><i class="bi bi-buildings"></i>Rede socioassistencial</div><h1>Unidades</h1><p>Visão consolidada das unidades, evitando quatro itens separados no menu principal.</p></div><div class="page-actions"><button class="btn btn-light" type="button" data-demo-action="exportar unidades"><i class="bi bi-download"></i>Exportar</button><button class="btn btn-primary" type="button" data-demo-action="cadastrar unidade"><i class="bi bi-plus-lg"></i>Nova unidade</button></div></header>

                <section class="compact-stats"><div class="compact-stat"><span>Unidades ativas</span><strong>4</strong></div><div class="compact-stat"><span>Profissionais</span><strong>86</strong></div><div class="compact-stat"><span>Atendimentos no mês</span><strong>2.418</strong></div><div class="compact-stat"><span>Territórios cobertos</span><strong>19</strong></div></section>

                <section class="unit-overview-grid" aria-label="Unidades cadastradas">
                    <article class="unit-overview-card"><div class="unit-overview-head"><span class="unit-icon"><i class="bi bi-geo-alt"></i></span><span class="status-badge status-success">Ativa</span></div><h2>CRAS 1</h2><p>Proteção social básica e acompanhamento familiar no território de referência.</p><dl><div><dt>Famílias acompanhadas</dt><dd>824</dd></div><div><dt>Atendimentos no mês</dt><dd>612</dd></div><div><dt>Equipe</dt><dd>18 profissionais</dd></div></dl><a class="btn btn-light w-100" href="cras1.php">Abrir painel da unidade</a></article>
                    <article class="unit-overview-card"><div class="unit-overview-head"><span class="unit-icon"><i class="bi bi-geo-alt"></i></span><span class="status-badge status-success">Ativa</span></div><h2>CRAS 2</h2><p>Proteção social básica, busca ativa e serviços de convivência territorial.</p><dl><div><dt>Famílias acompanhadas</dt><dd>706</dd></div><div><dt>Atendimentos no mês</dt><dd>548</dd></div><div><dt>Equipe</dt><dd>17 profissionais</dd></div></dl><a class="btn btn-light w-100" href="cras2.php">Abrir painel da unidade</a></article>
                    <article class="unit-overview-card"><div class="unit-overview-head"><span class="unit-icon"><i class="bi bi-shield-check"></i></span><span class="status-badge status-success">Ativa</span></div><h2>CREAS</h2><p>Proteção social especial e acompanhamento de situações de violação de direitos.</p><dl><div><dt>Casos acompanhados</dt><dd>216</dd></div><div><dt>Atendimentos no mês</dt><dd>384</dd></div><div><dt>Equipe</dt><dd>22 profissionais</dd></div></dl><a class="btn btn-light w-100" href="creas.php">Abrir painel da unidade</a></article>
                    <article class="unit-overview-card"><div class="unit-overview-head"><span class="unit-icon"><i class="bi bi-building"></i></span><span class="status-badge status-success">Ativa</span></div><h2>Casa do Cidadão</h2><p>Atendimento integrado, documentação, benefícios e orientação ao cidadão.</p><dl><div><dt>Cadastros vinculados</dt><dd>1.284</dd></div><div><dt>Atendimentos no mês</dt><dd>874</dd></div><div><dt>Equipe</dt><dd>29 profissionais</dd></div></dl><a class="btn btn-light w-100" href="casa.php">Abrir painel da unidade</a></article>
                </section>
            </main>
            <footer class="app-footer"><span>Dados demonstrativos utilizados apenas para prototipação.</span><span>SIGAS Coari — SEMAS Coari/AM</span></footer>
        </div>
        <div id="bottomNavigation"></div>
    </div>
    <div class="toast-container position-fixed top-0 end-0 p-3" id="toastContainer"></div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <?= PageContext::script($frontendContext) ?>
    <script src="assets/js/app.js"></script>
</body>
</html>

