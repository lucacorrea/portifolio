<?php

declare(strict_types=1);

use App\Core\PageContext;

require_once __DIR__ . '/bootstrap.php';

$frontendContext = PageContext::requireAuthenticatedFrontendContext();
?>
<!doctype html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Painel demonstrativo de integração somente leitura entre SIGAS Coari e SEMTH.">
    <title>SIGAS Coari — Integração SEMTH</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">
</head>
<body data-page="assistencia-semth" data-module="assistencia-social">
    <div class="app-shell">
        <aside class="app-sidebar" id="appSidebar" aria-label="Menu principal"></aside>
        <div class="app-main">
            <header class="app-topbar" id="appTopbar"></header>
            <main class="app-content">
                <header class="page-header">
                    <div>
                        <div class="eyebrow"><i class="bi bi-database-lock"></i>Governança de dados</div>
                        <h1>Integração SEMTH</h1>
                        <p>Consulta controlada ao sistema existente para prevenir duplicidades sem compartilhar operações de escrita.</p>
                    </div>
                    <div class="page-actions">
                        <span class="status-badge status-success" data-integration-health><i class="bi bi-check-circle-fill"></i>Conectado em modo somente leitura</span>
                        <button class="btn btn-light" type="button" data-integration-test><i class="bi bi-activity"></i>Testar leitura</button>
                    </div>
                </header>

                <section class="integration-architecture-banner" aria-label="Arquitetura da integração">
                    <div class="architecture-system local">
                        <span><i class="bi bi-grid-1x2"></i></span>
                        <div><strong>SIGAS Coari</strong><small>Base nova · leitura e gravação próprias</small></div>
                    </div>
                    <div class="architecture-link">
                        <span><i class="bi bi-arrow-left"></i> SELECT <i class="bi bi-arrow-right"></i></span>
                        <small>CPF, nome, nascimento e NIS</small>
                    </div>
                    <div class="architecture-system legacy">
                        <span><i class="bi bi-database-lock"></i></span>
                        <div><strong>SEMTH / SEMAS</strong><small>Base existente · consulta somente leitura</small></div>
                    </div>
                    <div class="architecture-blocked"><i class="bi bi-slash-circle"></i><span>INSERT · UPDATE · DELETE bloqueados</span></div>
                </section>

                <section class="compact-stats integration-stats" aria-label="Indicadores da integração">
                    <div class="compact-stat"><span>Referências consultáveis</span><strong>15.230</strong></div>
                    <div class="compact-stat"><span>Registros vinculados</span><strong>1.842</strong></div>
                    <div class="compact-stat"><span>Consultas hoje</span><strong>386</strong></div>
                    <div class="compact-stat"><span>Duplicidades bloqueadas</span><strong>27</strong></div>
                    <div class="compact-stat"><span>Divergências abertas</span><strong class="text-danger">12</strong></div>
                    <div class="compact-stat"><span>Última leitura</span><strong class="fs-6" data-integration-time>—</strong></div>
                </section>

                <section class="dashboard-grid" id="consulta">
                    <article class="content-card col-span-7 integration-query-card" data-integration-explorer>
                        <div class="card-heading">
                            <div><div class="card-kicker">Consulta preventiva</div><h2>Comparar uma identidade</h2><p>Este teste reproduz o retorno que será utilizado antes de qualquer novo cadastro.</p></div>
                            <span class="source-badge source-legacy"><i class="bi bi-database-lock"></i>SEMTH somente leitura</span>
                        </div>
                        <form id="integrationLookupForm" class="integration-query-form" novalidate>
                            <div class="flex-grow-1"><label class="form-label" for="integrationLookupCpf">CPF</label><input class="form-control form-control-lg" id="integrationLookupCpf" inputmode="numeric" maxlength="14" placeholder="000.000.000-00"><div class="invalid-feedback">Informe os 11 números do CPF.</div></div>
                            <div><label class="form-label" for="integrationLookupScenario">Cenário</label><select class="form-select form-select-lg" id="integrationLookupScenario"><option value="">Definir pelo CPF</option><option value="none">Não encontrada</option><option value="sigas-only">Somente SIGAS</option><option value="semth-only">Somente SEMTH</option><option value="linked">Já vinculada</option><option value="conflict">Divergência</option></select></div>
                            <button class="btn btn-primary btn-lg" type="submit"><i class="bi bi-search"></i>Comparar</button>
                        </form>
                        <div class="integration-query-empty" id="integrationQueryEmpty"><i class="bi bi-arrow-left-right"></i><span>Informe um CPF para comparar as duas fontes.</span></div>
                        <div class="integration-query-result" id="integrationQueryResult" hidden>
                            <div class="integration-query-result-head"><span class="mini-avatar" id="integrationQueryAvatar">—</span><div><strong id="integrationQueryName">Resultado</strong><span id="integrationQueryCpf">CPF</span></div><span class="status-badge" id="integrationQueryStatus">—</span></div>
                            <div class="identity-source-grid" id="integrationQuerySources"></div>
                            <div class="result-alert mt-3" id="integrationQueryAlert"><i class="bi bi-info-circle"></i><div><strong id="integrationQueryTitle"></strong><span id="integrationQueryMessage"></span></div></div>
                        </div>
                    </article>

                    <article class="content-card col-span-5">
                        <div class="card-heading"><div><div class="card-kicker">Regras permanentes</div><h2>Propriedade dos dados</h2><p>O vínculo não transforma as duas bases em um único banco.</p></div></div>
                        <div class="ownership-rule-list">
                            <div><span class="notice-icon success"><i class="bi bi-database-check"></i></span><div><strong>O SIGAS altera somente o SIGAS</strong><p>Cadastros, atendimentos, benefícios e documentos novos permanecem na base nova.</p></div></div>
                            <div><span class="notice-icon info"><i class="bi bi-database-lock"></i></span><div><strong>O SEMTH permanece independente</strong><p>O retorno legado é exibido como referência, sem botões de editar ou excluir.</p></div></div>
                            <div><span class="notice-icon warning"><i class="bi bi-person-check"></i></span><div><strong>Divergência exige análise humana</strong><p>Nenhum campo é substituído automaticamente quando as fontes discordam.</p></div></div>
                            <div><span class="notice-icon danger"><i class="bi bi-ban"></i></span><div><strong>Duplicidade bloqueia criação</strong><p>Quando o CPF já existe no SIGAS, o usuário é direcionado ao cadastro atual.</p></div></div>
                        </div>
                    </article>

                    <article class="content-card col-span-12">
                        <div class="card-heading"><div><div class="card-kicker">Contrato de acesso</div><h2>Matriz de permissões entre sistemas</h2><p>Configuração mínima recomendada para produção.</p></div></div>
                        <div class="table-responsive">
                            <table class="data-table integration-matrix">
                                <thead><tr><th>Operação</th><th>Base SIGAS</th><th>Base SEMTH</th><th>Comportamento esperado</th></tr></thead>
                                <tbody>
                                    <tr><td>Consultar pessoa</td><td><span class="status-badge status-success">Permitido</span></td><td><span class="status-badge status-info">SELECT</span></td><td>Comparar CPF e exibir origem.</td></tr>
                                    <tr><td>Criar cadastro</td><td><span class="status-badge status-success">Permitido</span></td><td><span class="status-badge status-danger">Bloqueado</span></td><td>Gravar somente no SIGAS após validação.</td></tr>
                                    <tr><td>Editar cadastro</td><td><span class="status-badge status-success">Conforme perfil</span></td><td><span class="status-badge status-danger">Bloqueado</span></td><td>Campos legados continuam somente leitura.</td></tr>
                                    <tr><td>Excluir ou arquivar</td><td><span class="status-badge status-warning">Conforme política</span></td><td><span class="status-badge status-danger">Bloqueado</span></td><td>Nenhuma exclusão cruzada.</td></tr>
                                    <tr><td>Sincronização automática</td><td><span class="status-badge status-neutral">Desativada</span></td><td><span class="status-badge status-neutral">Desativada</span></td><td>Somente referência e auditoria.</td></tr>
                                </tbody>
                            </table>
                        </div>
                    </article>

                    <article class="content-card col-span-12" id="divergencias">
                        <div class="card-heading"><div><div class="card-kicker">Revisão manual</div><h2>Divergências entre bases</h2><p>Casos que não devem ser corrigidos automaticamente.</p></div><button class="btn btn-light btn-sm" type="button" data-demo-action="exportar divergências"><i class="bi bi-download"></i>Exportar</button></div>
                        <div class="table-responsive">
                            <table class="data-table">
                                <thead><tr><th>CPF</th><th>Pessoa</th><th>SIGAS</th><th>SEMTH</th><th>Divergência</th><th>Estado</th><th>Ação</th></tr></thead>
                                <tbody>
                                    <tr><td>***.666.777-**</td><td><strong>Francisca Costa dos Santos</strong></td><td>PS-018448</td><td>SEMTH-008203</td><td>Nome abreviado no legado</td><td><span class="status-badge status-warning">Aguardando revisão</span></td><td><button class="btn btn-light btn-sm" type="button" data-demo-action="revisar divergência"><i class="bi bi-eye"></i>Revisar</button></td></tr>
                                    <tr><td>***.208.631-**</td><td><strong>José Pereira Lima</strong></td><td>PS-017932</td><td>SEMTH-007561</td><td>Data de nascimento divergente</td><td><span class="status-badge status-danger">Bloqueada</span></td><td><button class="btn btn-light btn-sm" type="button" data-demo-action="revisar divergência"><i class="bi bi-eye"></i>Revisar</button></td></tr>
                                    <tr><td>***.471.902-**</td><td><strong>Ana Maria Oliveira</strong></td><td>PS-016504</td><td>SEMTH-006234</td><td>NIS diferente</td><td><span class="status-badge status-info">Em análise</span></td><td><button class="btn btn-light btn-sm" type="button" data-demo-action="revisar divergência"><i class="bi bi-eye"></i>Revisar</button></td></tr>
                                </tbody>
                            </table>
                        </div>
                    </article>
                </section>
            </main>
            <footer class="app-footer"><span>Protótipo de integração sem escrita cruzada.</span><span>SIGAS Coari — SEMAS Coari/AM</span></footer>
        </div>
        <div id="bottomNavigation"></div>
    </div>

    <div class="toast-container position-fixed top-0 end-0 p-3" id="toastContainer"></div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/integration-demo.js"></script>
    <?= PageContext::script($frontendContext) ?>
    <script src="assets/js/app.js"></script>
</body>
</html>

