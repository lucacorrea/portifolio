<?php

declare(strict_types=1);

use App\Core\Csrf;
use App\Core\Database;
use App\Core\Logger;
use App\DTO\ComidaMesaPoloData;
use App\Repositories\AccessLevelRepository;
use App\Repositories\AuditLogRepository;
use App\Repositories\ComidaMesaRepository;
use App\Repositories\PermissionRepository;
use App\Repositories\UserRepository;
use App\Repositories\UserSessionRepository;
use App\Services\AuditService;
use App\Services\AuthService;
use App\Services\AuthorizationService;
use App\Services\ComidaMesaService;
use App\Services\PermissionService;

require_once dirname(__DIR__, 2) . '/bootstrap.php';

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

function cm_polo_json(int $status, array $payload): never
{
    http_response_code($status);
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function cm_polo_error(RuntimeException $exception): never
{
    $payload = ['ok' => false, 'error' => $exception->getMessage()];

    if ($exception->getCode() === 422) {
        $decoded = json_decode($exception->getMessage(), true);
        $payload = ['ok' => false, 'error' => 'Revise os campos informados.'];
        if (is_array($decoded['fields'] ?? null)) {
            $payload['fields'] = $decoded['fields'];
        }
    }

    $status = in_array($exception->getCode(), [400, 403, 404, 409, 419, 422], true)
        ? $exception->getCode()
        : 500;
    cm_polo_json($status, $payload);
}

try {
    if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
        header('Allow: POST');
        cm_polo_json(405, ['ok' => false, 'error' => 'Método não permitido.']);
    }

    if (!Csrf::validate($_POST['_csrf'] ?? null, 'comida_mesa_salvar_polo')) {
        cm_polo_json(419, ['ok' => false, 'error' => 'Requisição inválida.']);
    }

    $pdo = Database::connection();
    $levels = new AccessLevelRepository($pdo);
    $audit = new AuditService(new AuditLogRepository($pdo));
    $auth = new AuthService(new UserRepository($pdo), new UserSessionRepository($pdo), $levels, $audit);
    $user = $auth->currentUser();

    if ($user === null) {
        cm_polo_json(401, ['ok' => false, 'error' => 'Não autenticado.']);
    }

    $authorization = new AuthorizationService(new PermissionService(new PermissionRepository($pdo)), $levels);
    if (!$authorization->can($user, 'comida_mesa.polos_gerenciar')) {
        cm_polo_json(403, ['ok' => false, 'error' => 'Acesso negado.']);
    }

    $data = ComidaMesaPoloData::fromArray($_POST);
    $id = (new ComidaMesaService(new ComidaMesaRepository($pdo)))->savePole($data, $user->id, $audit);

    cm_polo_json($data->id === null ? 201 : 200, [
        'ok' => true,
        'message' => $data->id === null ? 'Polo cadastrado.' : 'Polo atualizado.',
        'data' => ['id' => $id],
    ]);
} catch (RuntimeException $exception) {
    cm_polo_error($exception);
} catch (Throwable $exception) {
    Logger::application('Comida Mesa pole save failed.', [
        'type' => $exception::class,
        'code' => $exception->getCode(),
    ]);
    cm_polo_json(500, ['ok' => false, 'error' => 'Não foi possível salvar o polo.']);
}
