<?php

declare(strict_types=1);

use App\Core\PageContext;

require_once __DIR__ . '/bootstrap.php';

$frontendContext = PageContext::requireAuthenticatedFrontendContext();
?>
<!doctype html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Perfil da usuária do SIGAS Coari.">
    <title>SIGAS Coari — Meu perfil</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">
</head>
<body data-page="perfil">
    <div class="app-shell">
        <aside class="app-sidebar" id="appSidebar" aria-label="Menu principal"></aside>
        <div class="app-main">
            <header class="app-topbar" id="appTopbar"></header>
            <main class="app-content">
                <section class="profile-header user-profile-header"><span class="profile-avatar">MO</span><div class="profile-main"><div class="profile-code">Usuária SIGAS — USR-000014</div><h1>Maria Oliveira</h1><div class="profile-meta"><span><i class="bi bi-person-badge"></i> Assistente Social</span><span><i class="bi bi-building"></i> SEMAS — Sede Administrativa</span><span><i class="bi bi-envelope"></i> maria.oliveira@semas.gov.br</span></div></div><div class="profile-actions"><button class="btn btn-light" type="button" data-demo-action="alterar senha"><i class="bi bi-key"></i>Alterar senha</button><button class="btn btn-primary" type="button" data-bs-toggle="modal" data-bs-target="#profileModal"><i class="bi bi-pencil"></i>Editar perfil</button></div></section>
                <section class="dashboard-grid"><article class="content-card col-span-8"><div class="card-heading"><div><div class="card-kicker">Informações profissionais</div><h2>Perfil de acesso</h2></div><span class="status-badge status-success"><i class="bi bi-check-circle"></i>Conta ativa</span></div><div class="info-grid"><div><div class="info-row"><span>Nome completo</span><strong>Maria Oliveira</strong></div><div class="info-row"><span>CPF</span><strong>***.456.789-**</strong></div><div class="info-row"><span>Matrícula</span><strong>SEMAS-0142</strong></div><div class="info-row"><span>Cargo</span><strong>Assistente Social</strong></div></div><div><div class="info-row"><span>Unidade</span><strong>SEMAS — Sede Administrativa</strong></div><div class="info-row"><span>Perfil</span><strong>Técnico com concessão</strong></div><div class="info-row"><span>Último acesso</span><strong>Hoje, 17:42</strong></div><div class="info-row"><span>Conta criada</span><strong>12/02/2024</strong></div></div></div><hr class="my-4"><div class="card-heading"><div><div class="card-kicker">Permissões principais</div><h2>Escopo autorizado</h2></div></div><div class="permission-grid"><div class="permission-item"><i class="bi bi-check-circle"></i><span>Consultar pessoas e famílias</span></div><div class="permission-item"><i class="bi bi-check-circle"></i><span>Registrar atendimentos</span></div><div class="permission-item"><i class="bi bi-check-circle"></i><span>Emitir parecer técnico</span></div><div class="permission-item"><i class="bi bi-check-circle"></i><span>Conceder benefícios autorizados</span></div><div class="permission-item muted"><i class="bi bi-x-circle"></i><span>Gerenciar usuários</span></div><div class="permission-item muted"><i class="bi bi-x-circle"></i><span>Alterar configurações globais</span></div></div></article><article class="content-card col-span-4"><div class="card-heading"><div><div class="card-kicker">Atividade recente</div><h2>Histórico de acesso</h2></div></div><div class="timeline"><div class="timeline-item"><span class="timeline-dot"></span><div class="timeline-content"><strong>Sessão iniciada</strong><span>Hoje, 17:42 · Aplicativo desktop</span></div></div><div class="timeline-item"><span class="timeline-dot"></span><div class="timeline-content"><strong>Parecer técnico registrado</strong><span>Hoje, 16:18 · SOL-2026-00325</span></div></div><div class="timeline-item"><span class="timeline-dot"></span><div class="timeline-content"><strong>Família atualizada</strong><span>Hoje, 14:36 · FM-007830</span></div></div><div class="timeline-item"><span class="timeline-dot"></span><div class="timeline-content"><strong>Relatório gerado</strong><span>Ontem, 17:05 · Produção mensal</span></div></div></div></article><article class="content-card col-span-6"><div class="card-heading"><div><div class="card-kicker">Preferências</div><h2>Interface e notificações</h2></div></div><div class="setting-row"><div><strong>Resumo diário de pendências</strong><span>Receber aviso interno no início do expediente.</span></div><div class="form-check form-switch"><input class="form-check-input" type="checkbox" role="switch" checked></div></div><div class="setting-row"><div><strong>Alertas de prioridade alta</strong><span>Exibir notificação imediata na topbar.</span></div><div class="form-check form-switch"><input class="form-check-input" type="checkbox" role="switch" checked></div></div><div class="setting-row"><div><strong>Sidebar recolhida ao iniciar</strong><span>Preferência aplicada apenas em telas desktop.</span></div><div class="form-check form-switch"><input class="form-check-input" type="checkbox" role="switch"></div></div><button class="btn btn-primary mt-3" type="button" data-settings-save><i class="bi bi-check2"></i>Salvar preferências</button></article><article class="content-card col-span-6"><div class="card-heading"><div><div class="card-kicker">Segurança</div><h2>Sessões e dispositivos</h2></div></div><div class="device-item"><span class="notice-icon success"><i class="bi bi-pc-display"></i></span><div class="item-main"><strong>Windows · Aplicativo ChatGPT Desktop</strong><span>Sessão atual · Coari/AM · Hoje, 17:42</span></div><span class="status-badge status-success"><i class="bi bi-check-circle"></i>Atual</span></div><div class="device-item"><span class="notice-icon info"><i class="bi bi-phone"></i></span><div class="item-main"><strong>Android · Chrome</strong><span>Último acesso em 17/06/2026, 20:11</span></div><button class="btn btn-light btn-sm" type="button" data-confirm-action="Encerrar esta sessão?">Encerrar</button></div></article></section>
            </main>
            <footer class="app-footer"><span>Dados demonstrativos utilizados apenas para prototipação.</span><span>SIGAS Coari — SEMAS Coari/AM</span></footer>
        </div>
        <div id="bottomNavigation"></div>
    </div>
<div class="modal fade" id="profileModal" tabindex="-1" aria-labelledby="profileTitle" aria-hidden="true"><div class="modal-dialog modal-dialog-centered"><div class="modal-content"><div class="modal-header"><div><div class="eyebrow mb-1"><i class="bi bi-person"></i>Minha conta</div><h2 class="modal-title fs-5" id="profileTitle">Editar perfil</h2></div><button class="btn-close" type="button" data-bs-dismiss="modal" aria-label="Fechar"></button></div><div class="modal-body"><div class="mb-3"><label class="form-label" for="profileName">Nome</label><input class="form-control" id="profileName" value="Maria Oliveira" required></div><div class="mb-3"><label class="form-label" for="profilePhone">Telefone</label><input class="form-control" id="profilePhone" value="(97) 99999-0000" required></div><div><label class="form-label" for="profileEmail">E-mail</label><input class="form-control" id="profileEmail" type="email" value="maria.oliveira@semas.gov.br" required></div></div><div class="modal-footer"><button class="btn btn-light" type="button" data-bs-dismiss="modal">Cancelar</button><button class="btn btn-primary" type="button" data-submit-demo="Perfil atualizado com sucesso.">Salvar</button></div></div></div></div>

    <div class="modal fade" id="confirmationModal" tabindex="-1" aria-labelledby="confirmationTitle" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-sm"><div class="modal-content"><div class="modal-body text-center p-4"><span class="notice-icon warning mx-auto mb-3"><i class="bi bi-exclamation-triangle"></i></span><h2 class="fs-5" id="confirmationTitle">Confirmar ação</h2><p class="text-secondary small" id="confirmationText">Deseja continuar?</p><div class="d-grid gap-2 mt-4"><button class="btn btn-primary" id="confirmActionButton" type="button">Confirmar</button><button class="btn btn-light" type="button" data-bs-dismiss="modal">Cancelar</button></div></div></div></div>
    </div>

    <div class="toast-container position-fixed top-0 end-0 p-3" id="toastContainer"></div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.3/dist/chart.umd.min.js"></script>
    <script src="assets/js/integration-demo.js"></script>
    <?= PageContext::script($frontendContext) ?>
    <script src="assets/js/app.js"></script>
</body>
</html>

